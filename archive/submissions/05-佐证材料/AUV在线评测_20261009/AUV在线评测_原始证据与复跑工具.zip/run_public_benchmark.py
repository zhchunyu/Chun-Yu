"""GSM8K fixed 32-case zero-shot sample. No claims of full leaderboard evaluation."""
from pathlib import Path
import argparse, datetime, decimal, hashlib, json, os, re, sys, time
import urllib.request, urllib.error

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'public_benchmark'

def number(text):
    try:return str(decimal.Decimal(text.replace(',','').replace('$','').strip()).normalize())
    except decimal.InvalidOperation:return None

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');args=p.parse_args()
    cases=json.loads((DATA/'subset32.json').read_text(encoding='utf-8'))
    print('GSM8K sample:',len(cases),'execute:',args.execute,flush=True)
    if not args.execute:return
    key=os.environ.get('AUV_API_KEY')
    if not key:raise SystemExit('AUV_API_KEY is required in process memory.')
    base='https://u1199722-8rhl-44401267.westb.seetacloud.com:8443'
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    dest=DATA/'runs'/stamp;dest.mkdir(parents=True,exist_ok=False)
    rows=[]
    with (dest/'requests.jsonl').open('x',encoding='utf-8') as log:
        for c in cases:
            messages=[{'role':'system','content':'Solve the math problem accurately. Show your reasoning briefly, then write the final numeric answer on a line starting with ####.'},
                      {'role':'user','content':c['question']}]
            payload={'model':'persona','do_sample':False,'temperature':0,'max_tokens':600,'stream':False,'messages':messages}
            req=urllib.request.Request(base+'/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
            start=time.perf_counter();r={'id':c['id'],'request':payload,'source_index':c['source_index'],'gold_final':c['gold_final']}
            try:
                with urllib.request.urlopen(req,timeout=120) as res:
                    obj=json.loads(res.read().decode());out=obj['choices'][0]['message']['content']
                    matches=re.findall(r'####\s*([-+]?\$?\d[\d,]*(?:\.\d+)?)',out)
                    pred=matches[-1] if matches else None
                    r.update(success=True,http_status=res.status,response=obj,output=out,prediction_strict=pred,
                             strict_answer_correct=pred is not None and number(pred)==number(c['gold_final']))
                    fallback=re.findall(r'[-+]?\d[\d,]*(?:\.\d+)?',out)
                    last=fallback[-1] if fallback else None
                    r['last_number_diagnostic']=last
                    r['last_number_diagnostic_correct']=last is not None and number(last)==number(c['gold_final'])
            except urllib.error.HTTPError as e:r.update(success=False,http_status=e.code,error=e.read().decode('utf-8','replace'))
            except Exception as e:r.update(success=False,error_type=type(e).__name__,error=str(e))
            r['elapsed_s']=time.perf_counter()-start
            # A credential echoed by a server must never reach the evidence file.
            r=json.loads(json.dumps(r,ensure_ascii=False).replace(key,'[REDACTED]'))
            rows.append(r);log.write(json.dumps(r,ensure_ascii=False)+'\n');log.flush()
            print(f"{len(rows)}/{len(cases)} {c['id']} success={r.get('success')} correct={r.get('strict_answer_correct')} seconds={r['elapsed_s']:.3f}",flush=True)
            if len(rows)>=3 and all(not x.get('success') for x in rows[-3:]):break
            time.sleep(.2)
    n=sum(x.get('strict_answer_correct',False) for x in rows);success=sum(x.get('success',False) for x in rows)
    summary={'dataset':'GSM8K test fixed sample','scheduled':32,'attempted':len(rows),'successful_responses':success,
             'strict_correct':n,'strict_accuracy_all_attempts':n/len(rows) if rows else None,
             'strict_accuracy_success_only':n/success if success else None,
             'last_number_diagnostic_correct':sum(x.get('last_number_diagnostic_correct',False) for x in rows),
             'subset_sha256':hashlib.sha256((DATA/'subset32.json').read_bytes()).hexdigest(),
             'prompt_protocol':'zero-shot; custom brief reasoning and #### final-answer request; temperature=0; do_sample=false; max_tokens=600',
             'limitations':'32-case fixed subset only, not full GSM8K or official rank; answer extraction is strict ####; dataset contamination not audited; elapsed includes network and generation'}
    (dest/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
    print('Evidence directory:',dest,flush=True)

if __name__=='__main__':main()
