import fs from 'node:fs'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {validateExtractedEvent} from 'file:///D:/project/college/26_10_8_college/04-应用开发/OurCampus/supabase/functions/_shared/auv.js'
const root=path.dirname(fileURLToPath(import.meta.url))
const run=process.argv[2]
if(!run) throw new Error('Specify the actual full-run directory')
const cases=JSON.parse(fs.readFileSync(path.join(root,'cases.json'),'utf8'))
const byid=new Map(cases.map(c=>[c.id,c]))
const raw=fs.readFileSync(path.join(run,'requests.jsonl'),'utf8').trim().split(/\r?\n/).map(s=>JSON.parse(s))
const rows=[]
for(const r of raw.filter(r=>['catalog','alias','semantic'].includes(r.group))){
 const c=byid.get(r.id)
 const rec={id:r.id,group:r.group,gold:c.gold,input:c.text,request_success:r.success}
 if(r.success){
  rec.model_fields=r.checks.parsed
  rec.model_location_correct=r.checks.field_exact.building_id && r.checks.field_exact.building_name
  try {
   rec.accepted=validateExtractedEvent(r.output,c.text,null)
   rec.app_location_correct=rec.accepted.building_id===c.gold.building_id && rec.accepted.building_name===c.gold.building_name
   rec.app_type_correct=rec.accepted.type===c.gold.type
  }catch(e){rec.app_error={code:e.code,message:e.message}}
 }
 rows.push(rec)
}
const groups={}
for(const group of ['catalog','alias','semantic']){
 const rr=rows.filter(r=>r.group===group)
 groups[group]={attempted:rr.length,model_location_correct:rr.filter(r=>r.model_location_correct).length,app_location_correct:rr.filter(r=>r.app_location_correct).length,app_ambiguous:rr.filter(r=>r.accepted?.location_status==='ambiguous').length,app_type_correct:rr.filter(r=>r.app_type_correct).length}
}
const out={scope:'对真实模型回复执行本地当前validateExtractedEvent；未访问登录网关、数据库或地图UI；不能当作完整App端到端验收',groups,rows}
fs.writeFileSync(path.join(root,'evidence','app_postprocess.json'),JSON.stringify(out,null,2))
console.log(JSON.stringify({groups,scope:out.scope},null,2))
