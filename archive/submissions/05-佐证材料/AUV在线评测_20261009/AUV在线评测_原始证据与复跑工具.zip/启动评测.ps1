param([ValidateSet('quick','full')][string]$Phase='quick')
$ErrorActionPreference='Stop'
$auvPython='C:\Users\y7000\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $auvPython)) { throw '请安装Python并把脚本中的auvPython改为实际路径。' }
Write-Host '本脚本访问AUV接口进行推理，不会保存密钥。quick运行24题，full运行全部题；两者均保留失败记录。'
$auvSecure=Read-Host '输入AUV密钥（隐藏输入）' -AsSecureString
$auvPtr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($auvSecure)
try {
    $env:AUV_API_KEY=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($auvPtr)
    $env:PYTHONIOENCODING='utf-8'
    & $auvPython (Join-Path $PSScriptRoot 'run_evaluation.py') --execute --phase $Phase
    if ($LASTEXITCODE -ne 0) { throw ('评测退出代码：'+$LASTEXITCODE) }
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($auvPtr)
    [Environment]::SetEnvironmentVariable('AUV_API_KEY',$null,'Process')
}
