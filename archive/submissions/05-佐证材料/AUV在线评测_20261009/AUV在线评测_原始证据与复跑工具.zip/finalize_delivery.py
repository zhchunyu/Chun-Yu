"""Record final state and package evidence. Never deletes user files or stores credentials."""
from pathlib import Path
import datetime,hashlib,json,re,zipfile

ROOT=Path(__file__).resolve().parent
F=json.loads((ROOT/'evidence/findings.json').read_text(encoding='utf-8'))
S=F['summary'];P=F['public_benchmark'];M=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
audit=json.loads((ROOT/'audit/final_document_audit.json').read_text(encoding='utf-8'))
SOURCE_PACK=Path(r'D:\project\college\26_10_8_college\06-竞赛材料\05-佐证材料\新版_2D核对稿_20261009')
DEST=Path(r'D:\project\college\26_10_8_college\06-竞赛材料\05-佐证材料\AUV在线评测_20261009')

def copy_exclusive(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as out:out.write(source.read_bytes())
    if hashlib.sha256(target.read_bytes()).digest()!=hashlib.sha256(source.read_bytes()).digest():
        raise RuntimeError(f'Copy hash mismatch: {target}')

def scan_credentials(paths):
    pattern=re.compile(rb'(?:auv-[A-Za-z0-9]{24,}|sk-[A-Za-z0-9_-]{20,})')
    hits=[]
    for p in paths:
        if not p.is_file():continue
        if pattern.search(p.read_bytes()):hits.append(str(p))
        if p.suffix.lower() in {'.docx','.dotx','.xlsx','.zip'}:
            with zipfile.ZipFile(p) as z:
                for name in z.namelist():
                    if pattern.search(z.read(name)):hits.append(f'{p}::{name}')
    return hits

def main():
    if not all(x['visual_review_status']=='passed_every_page' for x in audit):
        raise RuntimeError('Final page-by-page visual review is incomplete.')
    if (ROOT/'AUV在线评测_原始证据与复跑工具.zip').exists() or DEST.exists():
        raise RuntimeError('Existing final delivery will not be overwritten.')
    attachments=[]
    for name in ('核验附件','采集包'):
        for source in sorted((SOURCE_PACK/name).rglob('*')):
            if source.is_file():
                relative=source.relative_to(SOURCE_PACK)
                attachments.append((source,ROOT/'deliverables'/relative))
    candidates=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]+[s for s,t in attachments]
    hits=scan_credentials(candidates)
    if hits:raise RuntimeError('Credential-pattern matches in files: '+json.dumps(hits,ensure_ascii=False))
    attachment_manifest=[]
    for source,target in attachments:
        copy_exclusive(source,target)
        attachment_manifest.append({'path':target.relative_to(ROOT/'deliverables').as_posix(),
            'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'bytes':source.stat().st_size})
    (ROOT/'evidence/original_attachment_manifest.json').write_text(json.dumps(attachment_manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'evidence/document_quality_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    M.update(execution_status='completed',online_successful_responses=S['successful_responses'],
        full_attempted=S['attempted'],skipped_base_comparison=24,model_accuracy=None,
        metric_policy='不生成混合综合准确率；分项见evidence/findings.json',public_gsm8k_subset=P,
        latency_s=S['performance']['latency'],updated_at=datetime.datetime.now().astimezone().isoformat(),
        source_address_history=['https://u1199722-6hqt-2f39f661.weste.seetacloud.com:8443',M['base_url']])
    (ROOT/'manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2),encoding='utf-8')
    status=json.loads((ROOT/'evidence/execution_status.json').read_text(encoding='utf-8'))
    status['historical_network_failure']=status.pop('network_diagnostic',None)
    status['AUV_successful_model_responses']=S['successful_responses']+P['successful_responses']
    status['count_scope']='正式自建任务和32题公共样本；不含快速组、别名冒烟与额外提示词/协议检查'
    status['model_quality_result']='已完成分项，见findings.json'
    status['model_latency_result']=S['performance']['latency']
    status['model_throughput_result']=S['performance']['load_waves']
    status['network_access']='用户更新为无沙箱并开放网络后成功；此前审批错误不属于AUV'
    status['word_qa']={'installed_word_path':r'C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE',
                       'word_com_version':'16.0','official_renderer':'已尝试，缺少LibreOffice',
                       'native_word_pdf_export':'成功','visual_qa_complete':all(x['visual_review_status']=='passed_every_page' for x in audit)}
    (ROOT/'evidence/execution_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    harness=json.loads((ROOT/'evidence/harness_verification.json').read_text(encoding='utf-8'))
    harness['AUV_online_successful_responses_at_harness_check']=harness.pop('AUV_online_successful_responses',0)
    harness['note']='此文件最初在联网前执行，只说明评分程序校验。真实结果见findings.json。'
    (ROOT/'evidence/harness_verification.json').write_text(json.dumps(harness,ensure_ascii=False,indent=2),encoding='utf-8')
    original_readme=(ROOT/'README.md').read_text(encoding='utf-8')
    (ROOT/'audit/README_before_live.md').write_text(original_readme,encoding='utf-8')
    lat=S['performance']['latency']['complete_response_s']
    paired=F.get('protocol_checks',{}).get('general_prompt_paired',{})
    lines=['# AUV在线多方法评测证据包','',
        '本轮已取得真实在线结果。原地址和受限网络错误保留为历史诊断，不计模型零分。',
        f"正式自建任务执行{S['attempted']}次，成功回复{S['successful_responses']}次；另完成GSM8K固定随机32题及协议、同题提示词检查。410条计划中的24条基础模型对照因未公告该模型而跳过。",'',
        f"- 平衡事件题类型：{S['groups']['semantic']['fields']['type']['passed']}/72。", 
        f"- 平衡事件题地点ID：{S['groups']['semantic']['fields']['building_id']['passed']}/72。",
        f"- GSM8K固定32题：{P['strict_correct']}/32；不是全量分数或排行榜。",
        f"- 通用16题原类型匹配{paired.get('primary_correct')}/16，内部复核提示{paired.get('verify_prompt_correct')}/16；数值字符串统一后分别{paired.get('primary_normalized_correct')}/16、{paired.get('verify_prompt_normalized_correct')}/16。",
        f"- 独立串行完整回复p50 {lat['p50']:.2f}s，p95 {lat['p95']:.2f}s，样本{lat['n']}。",'',
        '模型列表只公告gpt-3.5-turbo，但extract、persona及任意不存在的model字符串都可返回200。后台权重和LoRA切换未核验。一次无认证头推理请求返回200；这是有限协议检查，不是完整鉴权审计。', '',
        '自建题包含模板、重复和成对对照；410条计划中有275条不同输入。参考答案未独立二审；扫描训练输入的完全相同字符串为0，近义重叠和公共集污染未审阅。全部原始答案和失败均保存，没有择优重试。', '',
        '## 主要文件','',
        '- deliverables：独立评测报告及佐证材料整合版，DOCX和Word原生导出的PDF。',
        '- deliverables/核验附件、采集包：原佐证材料引用的28个文件，逐文件原样复制；不是本轮新采集的真实用户反馈。',
        '- evidence/document_quality_audit.json：最终9页独立报告与23页整合版的分页和逐页检查记录。',
        '- evidence/original_attachment_manifest.json：原附件路径、大小和SHA256。',
        '- evidence/findings.json：统一最终评分、字段、混淆矩阵、对照、规则基线比较和性能。',
        '- evidence/all_failure_cases.json：所有受测参考字段或协议失败。',
        '- evidence/persona_review.json：资料问答逐条审阅；当前助手审阅，非独立人工打分，人工分数留空。',
        '- evidence/app_postprocess.json：对真实回复执行当前本地地点核对；不是云端或手机端验收。',
        '- runs/20261009_191150_420593：主评测所有请求；快速组单独保存。',
        '- public_benchmark：GSM8K原来源、固定32题及所有回复。',
        '- protocol_runs：4条协议检查及16条同题提示词对照。',
        '- cases.json / manifest.json：输入、参考字段和校验值。', '',
        '## 复跑','',
        '在PowerShell打开本目录，执行 .\\启动评测.ps1 -Phase quick 或 -Phase full；密钥隐藏输入，仅存进程内存。每次创建新的时间目录，不覆盖原始记录。完整组最大并发4，默认质量题串行；当前正式执行使用3个并发质量请求，性能组串行隔离。',
        '如需按本次参数复跑，可设置环境变量AUV_API_KEY后执行 bundled Python run_evaluation.py --execute --phase full --interval 0.2 --timeout 120 --workers 3。不要把密钥写入共享配置。',
        '公共样本复跑：设置同一环境变量后执行 run_public_benchmark.py --execute。没有--execute不发请求。协议补充：执行run_protocol_checks.py，含一次无认证头和无效model检查。', '',
        '## 评分解释','',
        '严格JSON与恢复JSON分开；原始字段和楼层统一格式后的字段分别报。未给楼层/等待时间/时间段的期望为null/null/unknown。严重度只检查取值；没有统一严重度分级标准，不报严重度准确率。',
        '通用题数字字符串单独统一格式，不将格式差异说成计算错误；含解释的字符串不自动抽取答案。资料问答关键词检查只做烟雾检查，不能当作事实准确率或人工分数。',
        'p50/p95使用nearest-rank；首个非空content分块为客户端首响应，非服务器内部首token。completion_tokens/s包括网络与排队，非纯GPU解码速度。并发1/2/4各3批，不推断长期可用率或大规模承载能力。',
        '原始全部请求与成功回复两种分母均保存。模板和重复题不独立，描述性区间不可当作泛化置信区间。', '',
        '## 来源与文档质量','',
        'GSM8K来源：https://github.com/openai/grade-school-math，原测试集1319题，seed=20261009固定抽取32题，零样本自定义####答案协议。未产生MMLU、C-Eval、CMMLU或HumanEval成绩。',
        '原Word佐证材料字节保持不变。官方render_docx.py已尝试但缺少LibreOffice；开放权限后Word16.0正常，最终文档由Word原生导出PDF，并逐页查看图像。包内Word样式、原有图片和不涉及编辑的ZIP部件保持。',
        '佐证材料中的模型结果不能代替新APK、真实用户反馈或云端数据库验收。', '']
    (ROOT/'README.md').write_text('\n'.join(lines),encoding='utf-8')
    candidates=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    hits=scan_credentials(candidates)
    if hits:raise RuntimeError('Credential-pattern matches in files: '+json.dumps(hits,ensure_ascii=False))
    (ROOT/'evidence/credential_scan.json').write_text(json.dumps({'scanned_files':len(candidates),
        'credential_pattern_matches':0,'office_zip_members_scanned':True,
        'note':'仅保存扫描状态，不保存密钥或任何匹配文本。'},ensure_ascii=False,indent=2),encoding='utf-8')
    files=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or any(x in ['audit','__pycache__'] for x in p.relative_to(ROOT).parts):continue
        if p==ROOT/'evidence/checksums.json':continue
        if p.suffix=='.zip':continue
        files.append({'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
    (ROOT/'evidence/checksums.json').write_text(json.dumps(files,ensure_ascii=False,indent=2),encoding='utf-8')
    archive=ROOT/'AUV在线评测_原始证据与复跑工具.zip'
    if archive.exists():raise RuntimeError('Existing evidence archive will not be overwritten.')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob('*')):
            if not p.is_file() or p==archive or any(x in ['audit','__pycache__'] for x in p.relative_to(ROOT).parts):continue
            if p.suffix=='.zip':continue
            z.write(p,p.relative_to(ROOT).as_posix())
    dest=DEST
    dest.mkdir()
    for source in (ROOT/'deliverables').rglob('*'):
        if source.is_file():copy_exclusive(source,dest/source.relative_to(ROOT/'deliverables'))
    for source in [archive,ROOT/'README.md']:
        copy_exclusive(source,dest/source.name)
    final={'destination':str(dest),'archive':str(archive),'archive_bytes':archive.stat().st_size,'delivered_files':[p.name for p in dest.iterdir() if p.is_file()],
           'visual_review_complete':all(x['visual_review_status']=='passed_every_page' for x in audit),'source_unchanged':all(x['source_unchanged'] for x in audit)}
    (ROOT/'audit/delivery_manifest.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(final,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
