"""Render selected real requests as labeled evidence cards, never simulated screenshots."""
from pathlib import Path
import json,html
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak
from reportlab.lib.units import mm
import pypdfium2 as pdfium

ROOT=Path(__file__).resolve().parent
pdfmetrics.registerFont(TTFont('CJK',r'C:\Windows\Fonts\msyh.ttc',subfontIndex=0))
pdfmetrics.registerFont(TTFont('CJKbold',r'C:\Windows\Fonts\msyhbd.ttc',subfontIndex=0))
styles={'title':ParagraphStyle('title',fontName='CJKbold',fontSize=17,leading=24,spaceAfter=12,wordWrap='CJK'),
        'body':ParagraphStyle('body',fontName='CJK',fontSize=10,leading=16,spaceAfter=10,wordWrap='CJK'),
        'label':ParagraphStyle('label',fontName='CJKbold',fontSize=11,leading=17,spaceAfter=5,wordWrap='CJK')}

def main():
    finding=json.loads((ROOT/'evidence/findings.json').read_text(encoding='utf-8'));run=Path(finding['full_run'])
    rows={r['id']:r for r in [json.loads(s) for s in (run/'requests.jsonl').read_text(encoding='utf-8').splitlines()]}
    cases={c['id']:c for c in json.loads((ROOT/'cases.json').read_text(encoding='utf-8'))}
    chosen=[('semantic-029','半小时被改成40分钟'),('semantic-034','否定句地点误读'),('catalog-003','编号与当前目录不一致'),('persona-001','资料中没有当前时刻却推算剩余时间')]
    story=[]
    for i,(cid,title) in enumerate(chosen):
        if cid not in rows:continue
        if i:story.append(PageBreak())
        row=rows[cid];case=cases[cid]
        story.append(Paragraph('AUV真实输出核验 '+title,styles['title']))
        for label,text in [('记录编号',cid),('输入',case['text']),('参考答案或资料',json.dumps(case.get('fixture',case['gold']),ensure_ascii=False)),
                           ('模型原始回复',row.get('output') or row.get('error') or row.get('error_body')),('请求元数据',json.dumps({'model':row['request']['model'],'started_at':row['started_at'],'elapsed_s':round(row['elapsed_s'],3),'http_status':row.get('http_status'),'request_id':row.get('response',{}).get('id')},ensure_ascii=False)),
                           ('来源',str(run.relative_to(ROOT))+'/requests.jsonl；此页由真实日志排版，不是浏览器截图，不替换原始JSONL。')]:
            story.append(Paragraph(html.escape(label),styles['label']))
            story.append(Paragraph(html.escape(str(text)).replace('\n','<br/>'),styles['body']))
    dest=ROOT/'evidence/selected_output_records.pdf'
    SimpleDocTemplate(str(dest),pagesize=A4,leftMargin=23*mm,rightMargin=23*mm,topMargin=20*mm,bottomMargin=20*mm).build(story)
    out=ROOT/'audit/evidence_render';out.mkdir(exist_ok=True)
    doc=pdfium.PdfDocument(str(dest))
    for i in range(len(doc)):
        p=doc[i];p.render(scale=1.4).to_pil().save(out/f'page-{i+1}.png');p.close()
    print('Rendered evidence pages:',len(doc));doc.close()

if __name__=='__main__':main()
