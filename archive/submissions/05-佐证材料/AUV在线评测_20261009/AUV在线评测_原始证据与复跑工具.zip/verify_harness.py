"""Local harness checks. Mock outputs below are not AUV model replies."""
import json, math
from pathlib import Path
import run_evaluation as r

ROOT=Path(__file__).resolve().parent
cases=r.CASES
ids=[c['id'] for c in cases]
assert len(ids)==len(set(ids))
assert len(cases)==410
assert len([c for c in cases if c['group']=='semantic'])==72
assert all(sum(c['group']=='semantic' and c['gold']['type']==t for c in cases)==18 for t in ['safety','congestion','service','notice'])
for c in cases:
    g=c['gold']
    if 'building_id' in g and g['building_id'] is not None:assert r.LOC_BY_ID[g['building_id']]['name']==g['building_name']
    assert len(r.messages(c))==2

c=next(c for c in cases if c['group']=='semantic')
mock={'type':c['gold']['type'],'building_id':c['gold']['building_id'],'building_name':c['gold']['building_name'],
      'floor':c['gold'].get('floor'),'severity':'high','description':'LOCAL MOCK','estimated_wait_min':None,'time_window':'unknown','advice':'LOCAL MOCK'}
raw=json.dumps(mock,ensure_ascii=False)
good=r.checks(c,raw);assert good['json_strict'] and good['schema_valid'] and good['gold_all_exact']
floor_variant=mock.copy();floor_variant['floor']='3F'
normalized=r.checks(c,json.dumps(floor_variant));assert normalized['schema_valid'] and not normalized['gold_all_exact'] and normalized['normalized_gold_all_exact']
fenced=r.checks(c,'```json\n'+raw+'\n```');assert not fenced['json_strict'] and fenced['json_recoverable']
invalid=r.checks(c,'not a JSON reply');assert not invalid['json_strict'] and not invalid['catalog_pair_legal'] and not invalid['gold_all_exact']
bad=mock.copy();bad['building_id']='not-a-real-id';assert not r.checks(c,json.dumps(bad))['catalog_pair_legal']
missing=mock.copy();del missing['advice'];assert not r.checks(c,json.dumps(missing))['schema_valid']
assert r.stat([1,2,3,4,5])['p95']==5
assert r.wilson(0,0) is None
rows=[{'id':c['id'],'group':c['group'],'gold':c['gold'],'success':True,'elapsed_s':2,'checks':good},
      {'id':'semantic-local-failure','group':'semantic','gold':c['gold'],'success':False,'elapsed_s':4}]
s=r.summarize(rows,2,['extract'])
assert s['groups']['semantic']['gold_all_exact']['rate']==1
assert s['groups']['semantic']['gold_all_exact_all_attempts']['rate']==.5
empty=r.summarize([],410,[]);assert empty['semantic_macro_f1_success_only'] is None
assert r.clean({'x':'secret-key'},'secret-key')['x']=='[REDACTED]'

primary=[c for c in cases if c['group']=='semantic']
baseline=[]
for c in primary:
    obj=r.rule_baseline(c)
    fields={k:obj.get(k)==v for k,v in c['gold'].items() if k in obj}
    baseline.append({'id':c['id'],'input':c['text'],'gold':c['gold'],'output':obj,'field_checks':fields})
summary={k:{'passed':sum(x['field_checks'].get(k,False) for x in baseline if k in x['field_checks']),
            'total':sum(k in x['field_checks'] for x in baseline)} for k in ['type','building_id','building_name','floor','estimated_wait_min']}
(ROOT/'evidence/rule_baseline.json').write_text(json.dumps({'method':'固定关键词与正则，本地执行，不是AUV模型输出','rows':baseline,'summary':summary},ensure_ascii=False,indent=2),encoding='utf-8')
verification={'status':'passed','case_records':len(cases),'unique_texts':len(set(c['text'] for c in cases)),
              'local_harness_only':True,'mock_responses_count_as_AUV':False,
              'checked':['IDs','balanced semantic classes','catalog gold consistency','message construction','strict JSON versus recovered JSON','invalid output','invalid ID/name pair','missing field','nearest-rank percentile','Wilson empty input','request failure denominator','empty scores remain null','key redaction'],
              'rule_baseline_summary':summary,'AUV_online_successful_responses':0}
(ROOT/'evidence/harness_verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(verification,ensure_ascii=False,indent=2))
