"""Aggregate completed evidence without running additional model requests."""
from pathlib import Path
import argparse, collections, hashlib, json, statistics
import run_evaluation as r

ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('full_run');p.add_argument('public_run');args=p.parse_args()
    run=Path(args.full_run);public=Path(args.public_run)
    rows=[json.loads(s) for s in (run/'requests.jsonl').read_text(encoding='utf-8').splitlines()]
    cases={c['id']:c for c in r.CASES}
    # Recompute checks from saved outputs for a single, documented final scoring contract.
    for row in rows:
        if row.get('success'):row['checks']=r.checks(cases[row['id']],row['output'])
    summary=r.summarize(rows,len(r.CASES),['gpt-3.5-turbo'])
    summary.pop('manual_review_template')
    (ROOT/'evidence/full_scoring_v2.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    baseline=json.loads((ROOT/'evidence/rule_baseline.json').read_text(encoding='utf-8'))
    matched=[x for x in rows if x['group']=='semantic' and x.get('success')]
    baseby={x['id']:x for x in baseline['rows']}
    comparison={}
    for field in ['type','building_id','building_name','floor','estimated_wait_min']:
        comparison[field]={'paired_cases':len(matched),'model_raw_pass':sum(x['checks']['field_exact'][field] for x in matched),
            'model_normalized_pass':sum(x['checks']['normalized_field_exact'][field] for x in matched),
            'rule_pass':sum(baseby[x['id']]['field_checks'][field] for x in matched)}
    failures=[]
    for row in rows:
        if not row.get('success') or row.get('checks',{}).get('normalized_gold_all_exact') is False or row.get('checks',{}).get('answer_correct') is False:
            failures.append({'id':row['id'],'group':row['group'],'input':cases[row['id']]['text'],
                'gold':cases[row['id']]['gold'],'output':row.get('output'),'checks':row.get('checks'),
                'request_error':row.get('error') or row.get('error_body')})
    persona=[{'id':x['id'],'topic':cases[x['id']]['topic'],'question':cases[x['id']]['text'],'fixture':cases[x['id']]['fixture'],
              'output':x.get('output'),'smoke':x.get('checks'),'notes':None,'review_origin':'尚未逐条审阅'} for x in rows if x['group']=='persona']
    annotations=ROOT/'evidence/persona_annotations.json'
    if annotations.exists():
        ann=json.loads(annotations.read_text(encoding='utf-8'))
        for x in persona:x.update(ann.get(x['id'],{}))
    time_missing=[x for x in rows if x.get('success') and cases[x['id']]['model']=='extract' and cases[x['id']]['gold'].get('time_window')=='unknown']
    floor_missing=[x for x in rows if x.get('success') and cases[x['id']]['model']=='extract' and cases[x['id']]['gold'].get('floor') is None]
    duration_missing=[x for x in rows if x.get('success') and cases[x['id']]['model']=='extract' and cases[x['id']]['gold'].get('estimated_wait_min') is None]
    unknown={'time_window':r.ratio(time_missing,lambda x:x['checks']['field_exact']['time_window']),
             'floor':r.ratio(floor_missing,lambda x:x['checks']['field_exact']['floor']),
             'estimated_wait_min':r.ratio(duration_missing,lambda x:x['checks']['field_exact']['estimated_wait_min'])}
    public_summary=json.loads((public/'summary.json').read_text(encoding='utf-8'))
    findings={'full_run':str(run),'public_run':str(public),'summary':summary,'public_benchmark':public_summary,
              'matched_rule_comparison':comparison,'missing_information':unknown,
              'case_count':len(r.CASES),'unique_texts':len(set(x['text'] for x in r.CASES)),
              'model_identity':'API只公告gpt-3.5-turbo；extract/persona请求均可接受；权重和LoRA路径未核验；不能证明两个名字为不同模型',
              'pilot_run':'20261009_190658_265435，24条，另存，不纳入正式样本',
              'scoring_contract':'原始精确率；floor固定将3F/三楼/3层归一为3另报；其他字段不改原值；未给定时间填unknown；全部失败保留'}
    proots=sorted((ROOT/'protocol_runs').glob('*/summary.json'))
    if proots:
        protocol=json.loads(proots[-1].read_text(encoding='utf-8'))
        for v in protocol['general_variant']:
            if v.get('success'):v['checks']=r.checks(cases[v['pair_id']],v['output'])
        genprimary={x['id']:x for x in rows if x['group']=='general'}
        matchedgen=[(genprimary[v['pair_id']],v) for v in protocol['general_variant'] if v['pair_id'] in genprimary and v.get('success') and genprimary[v['pair_id']].get('success')]
        findings['protocol_checks']={'run':str(proots[-1].parent),'protocol':protocol['protocol'],'general_prompt_paired':{
            'pairs':len(matchedgen),'primary_correct':sum(a['checks']['answer_correct'] for a,b in matchedgen),
            'verify_prompt_correct':sum(b['checks']['answer_correct'] for a,b in matchedgen),
            'primary_normalized_correct':sum(a['checks']['normalized_answer_correct'] for a,b in matchedgen),
            'verify_prompt_normalized_correct':sum(b['checks']['normalized_answer_correct'] for a,b in matchedgen)},'scope':protocol['scope']}
    (ROOT/'evidence/findings.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'evidence/all_failure_cases.json').write_text(json.dumps(failures,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'evidence/persona_review.json').write_text(json.dumps(persona,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'full_attempted':len(rows),'full_success':summary['successful_responses'],
                      'semantic':summary['groups'].get('semantic'),'public':public_summary,'unknown':unknown},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
