"""Render native Word PDFs and audit sources, package fidelity, tables and page geometry."""
from pathlib import Path
import hashlib,json,zipfile
from docx import Document
from docx.oxml.ns import qn
from pypdf import PdfReader
import pdfplumber,pypdfium2 as pdfium

ROOT=Path(__file__).resolve().parent
reports=[]
for path in sorted((ROOT/'deliverables').glob('*.docx')):
    doc=Document(path);errors=[]
    for i,t in enumerate(doc.tables):
        pr=t._tbl.tblPr;width=pr.find(qn('w:tblW'))
        grid=[int(x.get(qn('w:w'))) for x in t._tbl.tblGrid]
        if width is None or width.get(qn('w:type'))!='dxa':errors.append(f'table {i}: tblW')
        elif int(width.get(qn('w:w')))!=sum(grid):errors.append(f'table {i}: grid total')
        for row in t.rows:
            widths=[int(c._tc.tcPr.find(qn('w:tcW')).get(qn('w:w'))) for c in row.cells]
            if widths!=grid:errors.append(f'table {i}: tcW')
    pdf=path.with_suffix('.pdf');reader=PdfReader(pdf)
    render=ROOT/'audit'/('final_render_'+path.stem);render.mkdir(exist_ok=True)
    pages=pdfium.PdfDocument(str(pdf));geometry=[]
    for i in range(len(pages)):
        page=pages[i];page.render(scale=1.6).to_pil().save(render/f'page-{i+1}.png');page.close()
    pages.close()
    with pdfplumber.open(pdf) as pdoc:
        for i,p in enumerate(pdoc.pages):
            words=p.extract_words()
            out=[w['text'] for w in words if w['x0']<35 or w['x1']>p.width-35 or w['top']<12 or w['bottom']>p.height-12]
            geometry.append({'page':i+1,'words':len(words),'out_of_safe_bounds':out})
    reports.append({'path':str(path),'pdf':str(pdf),'native_word_pages':len(reader.pages),'render_dir':str(render),
                    'tables':len(doc.tables),'images':len(doc.inline_shapes),'table_geometry_errors':errors,'page_checks':geometry,
                    'source_unchanged':hashlib.sha256(Path(r'D:\project\college\output\supporting_materials_2d_v2\OurCampus_二维应用佐证材料_核对稿_v2.docx').read_bytes()).hexdigest()=='df7157903255e941f96d285c9872c2cd4ad9b5a358d59e5a533c2e29bc241fac',
                    'visual_review_status':'pending_every_page_review','official_renderer':'missing soffice; native Word16.0 export used'})
(ROOT/'audit/final_document_audit.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items() if k!='page_checks'} for r in reports],ensure_ascii=False,indent=2))
