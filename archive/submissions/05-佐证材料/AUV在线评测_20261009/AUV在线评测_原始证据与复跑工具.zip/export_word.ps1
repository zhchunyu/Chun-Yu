$ErrorActionPreference='Stop'
$auvWordExe='C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE'
if (-not (Test-Path -LiteralPath $auvWordExe)) { throw '指定路径未找到Word。' }
$auvWordApp=$null
try {
    $auvWordApp=New-Object -ComObject Word.Application
    $auvWordApp.Visible=$false
    $auvWordApp.DisplayAlerts=0
    $auvOutputs=Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'deliverables') -Filter '*.docx'
    foreach($auvFile in $auvOutputs) {
        $auvDoc=$null
        try {
            $auvDoc=$auvWordApp.Documents.Open($auvFile.FullName,$false,$true)
            $auvPdf=[IO.Path]::ChangeExtension($auvFile.FullName,'.pdf')
            $auvDoc.ExportAsFixedFormat($auvPdf,17)
            Write-Output ($auvFile.Name+' pages='+$auvDoc.ComputeStatistics(2))
        } finally {
            if($null -ne $auvDoc) {$auvDoc.Close(0);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($auvDoc)}
        }
    }
} finally {
    if($null -ne $auvWordApp) {$auvWordApp.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($auvWordApp)}
}
