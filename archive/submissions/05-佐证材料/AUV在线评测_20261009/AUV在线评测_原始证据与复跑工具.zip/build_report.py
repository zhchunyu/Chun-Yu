"""Build report copies from the retained DOCX. No network or model requests."""
from pathlib import Path
from copy import deepcopy
import collections, hashlib, html, json, zipfile, re, statistics
from lxml import etree
from docx import Document
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from reportlab.graphics.shapes import Drawing,String,Rect,Line
from reportlab.graphics import renderPDF
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import pypdfium2 as pdfium

ROOT=Path(__file__).resolve().parent
SOURCE=Path(r'D:\project\college\output\supporting_materials_2d_v2\OurCampus_二维应用佐证材料_核对稿_v2.docx')
DELIVER=ROOT/'deliverables';DELIVER.mkdir(exist_ok=True)
ASSETS=ROOT/'assets';ASSETS.mkdir(exist_ok=True)
F=json.loads((ROOT/'evidence/findings.json').read_text(encoding='utf-8'))
S=F['summary'];G=S['groups'];P=F['public_benchmark']
APP=json.loads((ROOT/'evidence/app_postprocess.json').read_text(encoding='utf-8'))
QA=json.loads((ROOT/'evidence/persona_review.json').read_text(encoding='utf-8'))
MAN=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
RUN=Path(F['full_run'])
RR=[json.loads(x) for x in (RUN/'requests.jsonl').read_text(encoding='utf-8').splitlines()]
CASE={c['id']:c for c in json.loads((ROOT/'cases.json').read_text(encoding='utf-8'))}
PAGES=[]

def count(m):return f"{m['passed']}/{m['total']}" if m else '未取得'
def pct(m):return f"{count(m)}  {m['rate']*100:.1f}%" if m and m['rate'] is not None else '未取得'
def nstat(s,key='p50'):return f"{s[key]:.2f}" if s else '未取得'
def field(group,key,normalized=False):return G[group]['normalized_fields' if normalized else 'fields'][key]
def para(text):return ('p',text)
def note(text):return ('n',text)
def table(cap,heads,rows,widths):return ('table',cap,heads,rows,widths)
def image(path,caption,width=160):return ('image',str(path),caption,width)
def page(title,*blocks):PAGES.append({'title':title,'blocks':list(blocks)})

pdfmetrics.registerFont(TTFont('CJK',r'C:\Windows\Fonts\msyh.ttc',subfontIndex=0))
pdfmetrics.registerFont(TTFont('CJKbold',r'C:\Windows\Fonts\msyhbd.ttc',subfontIndex=0))
def chart(stem,rows,title):
    d=Drawing(620,35+len(rows)*36)
    d.add(String(0,d.height-17,title,fontName='CJKbold',fontSize=14))
    width=365;left=165
    for i,(label,m) in enumerate(rows):
        y=d.height-52-i*36
        d.add(String(0,y+5,label,fontName='CJK',fontSize=11))
        d.add(Rect(left,y,width,20,fillColor=colors.HexColor('#EEF1F0'),strokeColor=None))
        val=m['rate'] if m and m['rate'] is not None else 0
        d.add(Rect(left,y,width*val,20,fillColor=colors.HexColor('#276653'),strokeColor=None))
        d.add(String(left+width+10,y+5,count(m),fontName='CJKbold',fontSize=10))
    pdf=ASSETS/(stem+'.pdf');renderPDF.drawToFile(d,str(pdf))
    doc=pdfium.PdfDocument(str(pdf));p=doc[0];p.render(scale=2).to_pil().save(ASSETS/(stem+'.png'));p.close();doc.close()
    return ASSETS/(stem+'.png')

semantic=G['semantic']
classification=field('semantic','type')
rule=F['matched_rule_comparison']
mainchart=chart('semantic_fields',[(label,field('semantic',k,normalized)) for label,k,normalized in [
    ('事件类型','type',False),('地点编号','building_id',False),('地点标准名称','building_name',False),
    ('楼层事实一致','floor',True),('分钟数','estimated_wait_min',False),('时间段','time_window',False)]], '72条平衡事件题  按字段统计成功回复')

page('AUV在线模型性能评测',
 para(f"本轮对指定AUV服务取得{S['successful_responses']}条正式自建任务回复，并完成GSM8K测试集固定32题小样本。事件类型在成功回复中为{pct(classification)}。测试同时发现地点编号、缺失信息和问答事实的问题，因此保留系统地点核对与用户确认仍有必要。"),
 table('表9 本轮真实执行范围',['证据','请求或样本','用途'],[
  ['自建正式任务',f"{S['attempted']}次执行 / 410次计划",'多方法质量与性能检查'],
  ['请求成功',f"{S['successful_responses']}/{S['attempted']}",'本轮窗口内取得真实回复'],
  ['公共数学样本',f"{P['attempted']}/32题",'固定随机采样  零样本协议'],
  ['协议快速组','24次  单独保存','验证接口  不混入正式结果'],
  ['基础模型对照','24条未执行','API未公告基础模型名称'],
 ],[38,49,73]),
 para('模型列表只公告gpt-3.5-turbo；实际请求中的extract和persona均被接受。接口返回的名称不能证明后台权重身份或不同LoRA已切换，本报告评价该地址在所记请求下的行为。'),
 note('协议补充检查中，任意不存在的模型名也返回200。另一次未带Authorization请求返回200，说明该次请求未被拒绝；这不是完整的鉴权审计。'),
 note('地址 '+MAN['base_url']+'。测试时间为2026年10月9日，Asia/Shanghai。密钥未写入交付材料。'),
 note('所有自建题为合成场景；包含模板、成对对照与重复请求，不是真实学生聊天。未完成人工独立二审，不能用这些结果宣称排行榜名次或一般泛化能力。'))

counts=MAN['group_counts']
page('题目来源与比较方法',
 table('表10 自建评测方法与计划规模',['方法','条数','判据'],[
  ['地点目录 / 唯一别名',f"{counts['catalog']} / {counts['alias']}",'标准名称、编号与别名对应'],
  ['事件语义 / 资料问答',f"{counts['semantic']} / {counts['persona']}",'四类各18条 / 固定合成资料'],
  ['通用小任务',str(counts['general']),'计算、逻辑和JSON格式'],
  ['提示词位置 / 地点资料',f"{counts['placement']} / {counts['grounding']}",'同题成对  user与system / 给目录'],
  ['语句扰动 / 重复输出',f"{counts['robustness']} / {counts['repeat']}",'保留含义的改写 / 8题各3次'],
  ['长文本',str(counts['long_context']),'目标位于开头或末尾'],
  ['延迟 / 流式首响应',f"{counts['latency']} / {counts['streaming']}",'独立串行请求  保存SSE'],
  ['小并发',str(counts['load']),'并发1、2、4各3批'],
  ['基础模型对照',str(counts['base_comparison']),'未公告该模型  明确跳过'],
 ],[48,25,87]),
 para('410条计划含275条不同输入。地点目录采用同一模板，重复组与成对组有相同输入；没有把这些请求计为410种独立任务。四类事件按safety、congestion、service、notice平衡取样。'),
 para('原始字段精确匹配与楼层统一格式后的事实一致率分别计算。3F、三楼和3层统一为整数3，其余原始字段不改写；没有给定的楼层、时长和时段，分别期望null、null和unknown。严重度缺少统一分级阈值，只检查枚举合法性。'),
 note('扫描训练输入15,358行，其中6,552条不同文本；本题集完全相同输入为0。近义重叠未审阅，公开数据污染也未审查。题集、提示词、抽样种子和原始输出都随评测包保存。'))

conf=S['semantic_confusion'];classes=['safety','congestion','service','notice']
page('事件分类与字段提取',
 image(mainchart,'图12 四类事件题的原始字段及楼层事实一致率'),
 table('表11 事件类型混淆矩阵',['标准类别','safety','congestion','service','notice','无效'],[[a]+[str(conf[a][b]) for b in classes+['invalid']] for a in classes],[40,24,24,24,24,24]),
 para(f"事件类型macro-F1为{S['semantic_macro_f1_success_only']:.3f}，分母为取得回复的平衡语义题。原始全部参考字段精确匹配{pct(semantic['gold_all_exact'])}；统一楼层格式后全部字段一致{pct(semantic['normalized_gold_all_exact'])}。这些指标不评价开放文本摘要和建议的完整正确性。"),
 note(f"固定关键词规则与同批成功语义题对照：类别{rule['type']['rule_pass']}/{rule['type']['paired_cases']}；模型类别{rule['type']['model_raw_pass']}/{rule['type']['paired_cases']}。规则只提供简单基线，未据本轮模型结果调参，不代表最佳传统算法。"))

page('同题比较模型与固定规则',
 table('表20 同批平衡语义题的字段对照',['字段','AUV匹配 / 分母','固定规则匹配 / 分母'],[[label,f"{rule[k]['model_normalized_pass']}/{rule[k]['paired_cases']}",f"{rule[k]['rule_pass']}/{rule[k]['paired_cases']}"] for k,label in [('type','事件类型'),('building_id','地点编号'),('building_name','标准名称'),('floor','楼层事实'),('estimated_wait_min','等待或持续分钟')]],[48,56,56]),
 para('固定规则先按事件关键词计分，再用当前目录名称和唯一别名匹配地点，只识别阿拉伯数字楼层和分钟。这个简单基线对编号对应更直接，模型对汉字楼层与语言分类更适用；两者任务职责不同，不适合只用一个总分判断优劣。楼层空缺也进入分母，具体有楼层的场景需另看逐条记录。'),
 para('案例semantic-029原文为“教工餐厅现在要排队半小时”，模型输出estimated_wait_min=40，并补入“中午”；参考事实为30分钟，时段未知。模型能形成流畅摘要，但明确数值仍需核对。'),
 para('案例semantic-034原文为“不是2号公寓楼，12号公寓楼洗衣房队伍很长”，模型返回2号公寓楼并新增23分钟等待。本地地点核对把该原文视为多地点歧义，保留待选择状态，避免直接使用错误编号，但没有自动理解否定句。'),
 para('案例semantic-046原文为“智能温室的门禁设备无法识别卡片”，参考type为service，模型返回safety。这里只统计既定单人标准答案下的类别差异，不把一条有争议的边界样例推广为整个类别无效。'),
 note('未取得独立基础模型权重，因此未完成“基础模型与LoRA微调”的因果对照。模型类名、规则结果和本地后处理结果都能在原始证据包按题号查看。'))

ground=S['paired_comparisons']['grounding'];placement=S['paired_comparisons']['placement']
unknown=F['missing_information']
page('地点编号与缺失信息',
 table('表12 原始模型与本地地点核对',['题组','模型名称与ID均正确','本地核对后均正确'],[[label,f"{APP['groups'][g]['model_location_correct']}/{APP['groups'][g]['attempted']}",f"{APP['groups'][g]['app_location_correct']}/{APP['groups'][g]['attempted']}"] for g,label in [('catalog','目录68题'),('alias','别名35题'),('semantic','语义72题')]],[42,59,59]),
 para('上表模型名称要求项目标准名称；返回有效别名会使名称规范化不匹配，不能直接解释为不知道这个地点。ID不一致则表示与当前项目目录不兼容。核对列将真实回复交给本地当前validateExtractedEvent处理，按原文选地点；没有访问登录网关、数据库或地图界面。'),
 para(f"提供权威目录的完整对照{ground['complete_pairs']}对：编号匹配由{ground['primary_id_pass']}对变为{ground['variant_id_pass']}对；全部字段一致由{ground['primary_pass']}对变为{ground['variant_pass']}对。该比较只涉及同题行为，不能据此推导训练收益。"),
 table('表13 缺失字段是否保持未知',['原文缺失信息','保持未知 / 可评回复','含义'],[
  ['时间段',count(unknown['time_window']),'期望unknown，不能猜时段'],
  ['楼层',count(unknown['floor']),'期望null'],
  ['时长或等待分钟',count(unknown['estimated_wait_min']),'期望null'],
 ],[48,54,58]),
 note('本地核对会保留多地点歧义。否定句如“不在1号公寓楼，是11号公寓楼”可能同时匹配两个地点；不能声称后处理解决了全部语言理解问题。'))

robust=S['paired_comparisons']['robustness'];repeats=S['repeat']
longrows=[x for x in RR if x['group']=='long_context']
page('提示词扰动与重复一致性',
 table('表14 同题对照与重复检查',['检查','完成规模','结果'],[
  ['instruction放system',str(placement['complete_pairs'])+'对',f"原提示词一致{placement['primary_pass']}对 / system一致{placement['variant_pass']}对"],
  ['表达扰动',str(robust['complete_pairs'])+'对',f"原提示词一致{robust['primary_pass']}对 / 扰动后{robust['variant_pass']}对"],
  ['同题三次  字段一致',str(len(repeats))+'组',f"{sum(x['fields_identical'] for x in repeats)}/{len(repeats)}组"],
  ['同题三次  原文一致',str(len(repeats))+'组',f"{sum(x['raw_identical'] for x in repeats)}/{len(repeats)}组"],
 ],[54,28,78]),
 para('一致性只衡量重复输出是否相同，不代表答案正确。即使temperature为0并显式do_sample=false，服务内部参数处理与推理随机性仍需服务器日志核验；本轮以观察到的结果为准。'),
 table('表15 长文本目标位置实验',['输入字符数','目标位置','请求 / 字段事实'],[[str(len(CASE[x['id']]['text'])),'开头' if CASE[x['id']]['target_position']=='head' else '末尾',('成功 / '+str(bool(x.get('checks',{}).get('normalized_gold_all_exact')))) if x.get('success') else '失败  '+str(x.get('http_status') or x.get('error_type'))] for x in longrows],[40,30,90]),
 note('长文本实验只测试直接模型接口；当前应用输入上限为1000字。超出服务上下文限制的错误按协议失败保留，不当作模型语义错误或App已有长文能力。'))

perf=S['performance'];lat=perf['latency'];stream=perf['streaming'];waves=perf['load_waves']
page('在线响应与小规模并发',
 table('表16 独立性能请求的客户端指标',['指标','样本','结果'],[
  ['串行完整回复 p50 / p95',str((lat['complete_response_s'] or {}).get('n',0)),f"{nstat(lat['complete_response_s'])} / {nstat(lat['complete_response_s'],'p95')} s"],
  ['流式完整回复 p50 / p95',str((stream['complete_response_s'] or {}).get('n',0)),f"{nstat(stream['complete_response_s'])} / {nstat(stream['complete_response_s'],'p95')} s"],
  ['首个非空content分块 p50',str((stream['first_nonempty_content_chunk_s'] or {}).get('n',0)),nstat(stream['first_nonempty_content_chunk_s'])+' s'],
  ['串行端到端完成token速率',str((lat['end_to_end_completion_tokens_per_s'] or {}).get('n',0)),nstat(lat['end_to_end_completion_tokens_per_s'])+' token/s 中位数'],
 ],[80,20,60]),
 table('表17 并发批次统计',['并发','三批成功 / 请求','批墙钟均值 s','吞吐均值 请求/s'],[[str(c),f"{sum(x['success'] for x in waves if x['concurrency']==c)}/{sum(x['attempted'] for x in waves if x['concurrency']==c)}",f"{statistics.mean(x['wave_wall_s'] for x in waves if x['concurrency']==c):.2f}",f"{statistics.mean(x['requests_per_s'] for x in waves if x['concurrency']==c):.3f}"] for c in [1,2,4]],[20,48,44,48]),
 para('耗时从客户端发出请求到获得完整回复，包含网络、服务排队、输入处理和生成。质量题使用3个并发请求提高执行效率，其耗时单独保存；上述性能组串行隔离执行。其他用户是否同时使用服务器无法确认。'),
 note('p50和p95采用nearest-rank；样本数小，p95可能接近最大值。首响应是收到非空文本分块的时刻，不等同服务器内部首token耗时；token/s为端到端指标，不是GPU纯解码速度。'),
 note('并发最大4、每档3批，只证明本轮小规模场景，不外推长期可用率、最大承载能力或生产SLA。所有错误与finish_reason均保存。'))

qa_flags=[x for x in QA if x.get('facts_supported') is False]
examples=qa_flags[:3]
genpair=F.get('protocol_checks',{}).get('general_prompt_paired',{})
page('资料问答与公开数学样本',
 table('表18 问答与计算范围',['任务','客观检查','结论边界'],[
  ['资料问答36题',count(G['persona'].get('pattern_smoke_only'))+' 关键词检查','关键词命中不等于事实正确'],
  ['自建通用16题',count(G['general'].get('answer_correct'))+' 严格答案','自建题，不称为公开榜单'],
  ['GSM8K固定32题',f"{P['strict_correct']}/{P['attempted']}  ####答案提取",'测试集小样本，不是全量分数'],
 ],[42,62,56]),
 para(f"GSM8K原测试集为1319题，按随机种子20261009抽取32题，采用零样本英文提示、简短推理与####最终数值，max_tokens=600。严格提取正确率{P['strict_accuracy_all_attempts']*100:.1f}%；末尾数字诊断另存，不能选择较高的一种当主要成绩。"),
 note(f"自建通用题的同题提示对照{genpair.get('pairs',0)}对：按原类型，直接答案{genpair.get('primary_correct',0)}题匹配、内部复核提示{genpair.get('verify_prompt_correct',0)}题匹配；数值字符串统一后分别为{genpair.get('primary_normalized_correct',0)}和{genpair.get('verify_prompt_normalized_correct',0)}题。格式差异不等于算错。未重复多轮，不称为稳定提升率。"),
 para('资料问答逐条依据固定合成资料检查，记录支持、缺失与新增断言。此审阅由当前助手执行，不是第二位人工评分者；事实40等人工评分栏仍留空，不报告人工满意率或总评分。'),
 note('资料缺失人流题3/3被回答为“人不多”；资料内指令注入题3/3没有按21:30闭馆资料回答。三个近义版本属于同一任务，不计为三种独立攻击。'),
 *[note(x['id']+'  '+(x.get('notes') or '')+' 原文：'+(x.get('output') or '')[:180]) for x in examples],
 note('公开来源：https://github.com/openai/grade-school-math。来源文件、32条题号、参考答案、SHA256、全部输出随包保存。未执行全量MMLU、C-Eval、CMMLU或HumanEval，不使用这些榜单名称描述本轮成绩。'))

page('证据查阅与应用改进',
 para('本轮结果支持按字段审核模型输出。事件分类可用程度应依据分项结果判断；地点编号应由当前目录核对，原文缺失信息保持未知；时刻计算和等待估算等确定性任务优先用明确规则计算，再让模型解释。'),
 para('建议先核验服务器启动日志中的基础模型、checkpoint与LoRA切换机制，再补第三方基准工具的标准协议及独立二审。资料问答需要事实核对，不能仅靠关键词命中。新APK真机验收、真实用户反馈与在线数据库联调仍需另补。'),
 para('当前一次不带认证头的推理请求返回200，建议服务负责人核对服务端鉴权。任意model字符串被接受，需明确列出的模型名称是否绑定实际模型或仅作为兼容字段。'),
 table('表19 无需外部账号的证据入口',['结论','包内文件'],[
  ['题目与提示词','cases.json  manifest.json  catalog_snapshot.json'],
  ['正式回复与协议失败',str(RUN.relative_to(ROOT))+'/requests.jsonl'],
  ['字段与成对统计','evidence/findings.json  full_scoring_v2.json'],
  ['错误样例与问答审阅','evidence/all_failure_cases.json  persona_review.json'],
  ['当前App本地地点核对','evidence/app_postprocess.json  app_postprocess.mjs'],
  ['固定关键词规则','evidence/rule_baseline.json  run_evaluation.py'],
  ['协议与通用题提示词对照','protocol_runs/20261009_193551_399270/summary.json'],
  ['公开数学样本','public_benchmark/source_manifest.json  subset32.json  runs'],
  ['复跑入口','启动评测.ps1  run_public_benchmark.py  README.md'],
 ],[48,112]),
 note('请求不自动择优重试。全部失败保留；成功回复分母与全部请求分母分别统计。重复和模板题非独立，描述性比例或Wilson区间不能当作一般泛化置信区间。模型名称和参数来自API记录，不代替服务端版本证明。'),
 note('原Word佐证材料保持不变；本报告及整合版另存。Word原生导出PDF后逐页核查；官方render_docx.py因缺少LibreOffice未完成，已用安装的Word16.0验证原生分页。'))

def elem(tag,attrs=None):
    e=OxmlElement(tag)
    for k,v in (attrs or {}).items():e.set(qn('w:'+k),str(v))
    return e

def format_table(t,widths):
    total=round(sum(widths)*56.692913)
    gridwidths=[round(w*56.692913) for w in widths[:-1]]
    gridwidths.append(total-sum(gridwidths))
    pr=t._tbl.tblPr
    for tag in ['w:tblW','w:tblInd','w:tblLayout','w:tblBorders','w:tblCellMar']:
        old=pr.find(qn(tag))
        if old is not None:pr.remove(old)
    pr.append(elem('w:tblW',{'w':total,'type':'dxa'}));pr.append(elem('w:tblInd',{'w':0,'type':'dxa'}));pr.append(elem('w:tblLayout',{'type':'fixed'}))
    b=elem('w:tblBorders')
    for edge in ['top','left','bottom','right','insideH','insideV']:b.append(elem('w:'+edge,{'val':'single','sz':4,'color':'D9D9D9'}))
    pr.append(b);mar=elem('w:tblCellMar')
    for edge in ['top','left','bottom','right']:mar.append(elem('w:'+edge,{'w':90,'type':'dxa'}))
    pr.append(mar);grid=t._tbl.tblGrid
    for child in list(grid):grid.remove(child)
    for w in gridwidths:grid.append(elem('w:gridCol',{'w':w}))
    for i,row in enumerate(t.rows):
        rp=row._tr.get_or_add_trPr();rp.append(elem('w:cantSplit'))
        if i==0:rp.append(elem('w:tblHeader'))
        for j,c in enumerate(row.cells):
            c.width=Cm(widths[j]/10);cp=c._tc.get_or_add_tcPr();tcw=cp.find(qn('w:tcW'));tcw.set(qn('w:w'),str(gridwidths[j]));tcw.set(qn('w:type'),'dxa')
            cp.append(elem('w:shd',{'fill':'E8EEE9' if i==0 else 'FFFFFF','val':'clear'}))
            c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for p in c.paragraphs:
                p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_after=Pt(1);p.paragraph_format.space_before=Pt(1)
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 or widths[j]>50 else WD_ALIGN_PARAGRAPH.CENTER
                for run in p.runs:run.font.size=Pt(9);run.font.bold=i==0

def make_content():
    d=Document(SOURCE)
    body=d._element.body
    for child in list(body):
        if child.tag!=qn('w:sectPr'):body.remove(child)
    d.core_properties.title='AUV在线模型性能评测';d.core_properties.author='';d.core_properties.last_modified_by=''
    for i,pg in enumerate(PAGES):
        if i:d.add_page_break()
        p=d.add_paragraph(pg['title'],style='Title' if i==0 else 'Heading 1')
        pp=p._p.get_or_add_pPr();border=elem('w:pBdr');border.append(elem('w:bottom',{'val':'nil'}));pp.append(border)
        for run in p.runs:run.font.color.rgb=__import__('docx').shared.RGBColor(0,0,0)
        for b in pg['blocks']:
            if b[0] in ['p','n']:
                p=d.add_paragraph(b[1]);p.paragraph_format.line_spacing=1.15;p.paragraph_format.space_after=Pt(7)
                if b[0]=='n':
                    for run in p.runs:run.font.size=Pt(9)
            elif b[0]=='table':
                p=d.add_paragraph(b[1],style='Caption');p.paragraph_format.keep_with_next=True
                t=d.add_table(rows=1,cols=len(b[2]));t.autofit=False
                for j,x in enumerate(b[2]):t.rows[0].cells[j].text=str(x)
                for row in b[3]:
                    cells=t.add_row().cells
                    for j,x in enumerate(row):cells[j].text=str(x)
                format_table(t,b[4]);d.add_paragraph().paragraph_format.space_after=Pt(1)
            elif b[0]=='image':
                p=d.add_paragraph();p.paragraph_format.keep_with_next=True;p.add_run().add_picture(b[1],width=Cm(b[3]/10))
                d.add_paragraph(b[2],style='Caption')
    return d

def serialize(e):return etree.tostring(e,encoding='UTF-8',xml_declaration=True,standalone=True)

def patch_source(newdoc,out,standalone=False):
    # Only document.xml and image/content type relationships may change; all other ZIP members preserve their bytes.
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    relns='http://schemas.openxmlformats.org/package/2006/relationships'
    ctns='http://schemas.openxmlformats.org/package/2006/content-types'
    with zipfile.ZipFile(SOURCE) as z:original={n:z.read(n) for n in z.namelist()};infos={x.filename:x for x in z.infolist()}
    source=etree.fromstring(original['word/document.xml']);body=source.find('w:body',ns)
    rels=etree.fromstring(original['word/_rels/document.xml.rels']);ct=etree.fromstring(original['[Content_Types].xml'])
    sect=body.find('w:sectPr',ns)
    source_paragraphs=body.findall('w:p',ns)
    if standalone:
        for child in list(body):
            if child is not sect:body.remove(child)
    else:
        replacements={
            7:'模型在线评测已补入本稿附录，记录分项能力、失败样例和响应耗时；最新APK真机操作与用户反馈仍待补齐。原有离线校验不作为模型准确率。',
            37:'60/60项离线资料传递检查通过，只验证资料怎样进入请求。真实模型的资料问答、未知信息处理及错误样例见新增在线评测附录。',
            104:'本稿附录已加入真实在线模型评测。正式提交前仍需补齐新APK安装记录、使用者反馈、云端联调与外部创新检索；模型身份和参考答案需独立复核。',
        }
        for idx,text in replacements.items():
            p=source_paragraphs[idx];ts=p.findall('.//w:t',ns)
            if not ts:raise ValueError(f'No text in source slot {idx}')
            ts[0].text=text
            for t in ts[1:]:t.text=''
        for p in body.findall('.//w:tc/w:p',ns):
            ts=p.findall('.//w:t',ns);text=''.join(t.text or '' for t in ts)
            if text=='后续在线评测':ts[0].text='真实在线模型评测'
            if text=='evaluation/online_quality_cases.json、online_runner.mjs':
                ts[0].text='新增在线评测附录及AUV在线评测证据包'
                for t in ts[1:]:t.text=''
        br=elem('w:p');run=elem('w:r');breakel=elem('w:br',{'type':'page'});run.append(breakel);br.append(run);body.insert(list(body).index(sect),br)
    additions={};idmap={};counter=1
    used={x.get('Id') for x in rels}
    newbody=newdoc._element.body
    content=[deepcopy(x) for x in newbody if x.tag!=qn('w:sectPr')]
    wpns='http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
    maxdocpr=max([int(x.get('id','0')) for x in source.findall('.//{'+wpns+'}docPr')]+[0])
    for e in content:
        for node in e.iter():
            if node.tag=='{'+wpns+'}docPr':maxdocpr+=1;node.set('id',str(maxdocpr))
            rid=node.get(qn('r:embed'))
            if rid and rid not in idmap:
                part=newdoc.part.related_parts[rid];target=f'media/auv_eval_{counter}.png'
                newid=f'rIdAuvEval{counter}'
                while newid in used:counter+=1;newid=f'rIdAuvEval{counter}'
                idmap[rid]=newid;used.add(newid)
                rel=etree.SubElement(rels,'{'+relns+'}Relationship');rel.set('Id',newid);rel.set('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/image');rel.set('Target',target)
                additions['word/'+target]=part.blob;counter+=1
            if rid:node.set(qn('r:embed'),idmap[rid])
        body.insert(list(body).index(sect),e)
    if additions and not any(x.get('Extension')=='png' for x in ct):
        el=etree.SubElement(ct,'{'+ctns+'}Default');el.set('Extension','png');el.set('ContentType','image/png')
    changes={'word/document.xml':serialize(source),'word/_rels/document.xml.rels':serialize(rels),'[Content_Types].xml':serialize(ct),**additions}
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for name,blob in original.items():z.writestr(infos[name],changes.get(name,blob))
        for name,blob in additions.items():z.writestr(name,blob)
    with zipfile.ZipFile(out) as z:
        changed=[n for n in original if z.read(n)!=original[n]]
    allowed={'word/document.xml','word/_rels/document.xml.rels','[Content_Types].xml'}
    assert set(changed)<=allowed
    return {'output':str(out),'changed_source_parts':changed,'new_parts':list(additions),'preserve_only_parts_pass':True}

def main():
    table_number=9
    for pg in PAGES:
        for i,b in enumerate(pg['blocks']):
            if b[0]=='table':
                pg['blocks'][i]=(b[0],re.sub(r'^表\d+',f'表{table_number}',b[1]),*b[2:]);table_number+=1
    d=make_content();audits=[]
    audits.append(patch_source(d,DELIVER/'AUV在线评测报告_20261009.docx',standalone=True))
    audits.append(patch_source(d,DELIVER/'OurCampus_佐证材料_AUV在线评测整合版.docx',standalone=False))
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='df7157903255e941f96d285c9872c2cd4ad9b5a358d59e5a533c2e29bc241fac'
    (ROOT/'audit/package_fidelity.json').write_text(json.dumps(audits,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=[]
    for i,pg in enumerate(PAGES):
        lines += [f'<!-- PAGE {i+1} -->','# '+pg['title'],'']
        for b in pg['blocks']:
            if b[0] in ['p','n']:lines += [b[1],'']
            elif b[0]=='image':lines += [f'![{b[2]}]({b[1]})','']
            elif b[0]=='table':
                lines += [b[1],'| '+' | '.join(b[2])+' |','| '+' | '.join(['---']*len(b[2]))+' |']
                lines += ['| '+' | '.join(map(str,row))+' |' for row in b[3]];lines += ['']
    (DELIVER/'AUV在线评测报告_可编辑正文.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Created report pages planned:',len(PAGES));print(json.dumps(audits,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
