"""Small protocol and same-question prompt checks; append-only run directory."""
from pathlib import Path
import datetime,json,os,time,urllib.request,urllib.error
import run_evaluation as r
ROOT=Path(__file__).resolve().parent

def main():
    key=os.environ['AUV_API_KEY'];base='https://u1199722-8rhl-44401267.westb.seetacloud.com:8443'
    dest=ROOT/'protocol_runs'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f');dest.mkdir(parents=True,exist_ok=False)
    seed=next(c for c in r.CASES if c['group']=='semantic')
    checks=[('unknown_model_alias',{'model':'auv-nonexistent-model-probe','messages':r.messages(seed),'temperature':0,'do_sample':False,'max_tokens':180,'stream':False},True),
            ('empty_messages',{'model':'persona','messages':[],'max_tokens':80},True),
            ('missing_model',{'messages':[{'role':'user','content':'你好'}],'max_tokens':80},True),
            ('no_auth',{'model':'persona','messages':[{'role':'user','content':'只回复接口测试'}],'max_tokens':80},False)]
    rows=[]
    with (dest/'requests.jsonl').open('x',encoding='utf-8') as log:
        for name,payload,use_auth in checks:
            headers={'Content-Type':'application/json'}
            if use_auth:headers['Authorization']='Bearer '+key
            req=urllib.request.Request(base+'/v1/chat/completions',data=json.dumps(payload,ensure_ascii=False).encode(),headers=headers)
            start=time.perf_counter();row={'id':name,'request':payload,'auth_provided':use_auth}
            try:
                with urllib.request.urlopen(req,timeout=60) as res:row.update(status=res.status,body=res.read().decode('utf-8','replace'))
            except urllib.error.HTTPError as e:row.update(status=e.code,body=e.read().decode('utf-8','replace'))
            except Exception as e:row.update(error=str(e))
            row['elapsed_s']=time.perf_counter()-start;row=r.clean(row,key);rows.append(row);log.write(json.dumps(row,ensure_ascii=False)+'\n');log.flush()
            print(name,row.get('status'),row['elapsed_s'],flush=True)
        class Args: max_tokens=600;timeout=90
        variants=[]
        for c in [c for c in r.CASES if c['group']=='general']:
            v={**c,'id':c['id']+'-verify','instruction':'请先在内部逐步计算并复核结果，然后只输出用户要求的JSON。不要输出解释或额外文字。'}
            row=r.call(base,key,v,Args());row['pair_id']=c['id'];variants.append(row);log.write(json.dumps(row,ensure_ascii=False)+'\n');log.flush()
            print(v['id'],row.get('success'),row.get('checks',{}).get('answer_correct'),flush=True)
    result={'protocol':rows,'general_variant':variants,'scope':'4条有限协议检查及16条同题提示词对照；不是安全审计或模型身份证明'}
    (dest/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Evidence directory:',dest,flush=True)

if __name__=='__main__':main()
