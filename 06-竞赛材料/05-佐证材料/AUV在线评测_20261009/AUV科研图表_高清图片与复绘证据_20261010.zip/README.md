# AUV科研图表版交付说明（2026-10-10）

配套文档：OurCampus_佐证材料_AUV科研图表版_20261010.docx / .pdf，共27页。原整合稿未修改；前19页像素一致保留，原AUV附录重编为8页、插入6幅技术图。

## 图表来源与使用

- 图12：评测与证据流转（diagrams/01_evaluation_workflow.png）。
- 图13：语义字段对照与混淆矩阵（stats/01_semantic_fields_confusion.*）。
- 图14：地点、未知信息和目录提示比较（stats/02_location_unknown_grounding.*）。
- 图15：本地校验和地点处理流程（diagrams/04_local_validation_flow.png）。
- 图16：同题提示词、扰动与GSM8K固定样本（stats/03_controlled_pairs_public_sample.*）。
- 图17：逐次延迟与并发（stats/04_latency_and_concurrency.*）。

四组统计图从2026-10-09保存的AUV真实记录计算，提供PNG、SVG、PDF及逐条CSV和所有绘图数值；本次没有新增AUV推理成绩。不得把不同题组混成模型总分，不得把32题样本当全量基准，也不得丢弃异常值。

两张框图用用户指定的 https://img-api.apinebula.ai/v1 / gpt-image-2.5 生成，再按实际评测逻辑和项目源码校正连线。它们是技术说明，不是现场截图或实测性能。generation/raw中两张v2图是校正前留档，存在已修复连接关系，仅用于审计；正式使用diagrams中的最终图。无动漫场景图。

## 复绘与核验

统计图复绘见stats/README.md，需另解压同目录原有“AUV在线评测_原始证据与复跑工具.zip”。本图表包不重复收录完整原始回复；plot_metrics.json保存10个源文件SHA256。绘图脚本只读取既有数据，不访问模型。依赖见stats/requirements.txt，vendor不打包。

连线校正可在本包解压目录运行：

```
python correct_diagram_connectors.py --source generation/raw --out-dir diagrams_reproduced
```

该步骤需要Pillow，使用随包校正前原图，不调用付费接口；重绘后仍需视觉审查。generation/prompts保存生成和迭代提示词；模型生成存在随机性，不保证再次生成逐像素一致。

audit记录数据、事实与版式核验。Word原生导出、pypdfium2逐页渲染检查27页；官方renderer因缺少LibreOffice不可用。新附录20–27页检查通过。源模板第15页U16反馈标题与第16页正文分离的既有分页保持原样，已记录。原稿SHA256及文档/图片摘要在manifest.json。文件摘要用于验证内容一致性，不表示独立第三方认证。

本包不含API密钥、DPAPI凭据、SDK或vendor依赖。原报告、旧场景图版和原始证据包均保留。
