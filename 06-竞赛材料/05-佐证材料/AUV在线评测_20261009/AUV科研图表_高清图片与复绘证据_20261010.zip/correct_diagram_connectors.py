"""Precise connector correction after reviewing AI-assisted technical drawings."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,argparse
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path,default=ROOT/'generation'/'raw' if (ROOT/'generation'/'raw').exists() else Path(r'D:\project\college\output\imagegen\auv_scientific_20261010'))
parser.add_argument('--out-dir',type=Path,default=ROOT/'diagrams')
args=parser.parse_args()
SRC=args.source
OUT=args.out_dir;OUT.mkdir(exist_ok=True,parents=True)
COLOR=(69,116,170)

def remove_vertical(im,x0,x1,y0,y1,sample_x):
    # Reconstruct the local background row-by-row, retaining horizontal lane borders.
    for y in range(y0,y1+1):
        sample=im.getpixel((sample_x,y))
        for x in range(x0,x1+1):im.putpixel((x,y),sample)

def arrow(draw,points,width=3):
    draw.line(points,fill=COLOR,width=width,joint='curve')
    x,y=points[-1];px,py=points[-2]
    if x==px:
        sign=1 if y>py else -1
        head=[(x,y),(x-6,y-sign*11),(x+6,y-sign*11)]
    else:
        sign=1 if x>px else -1
        head=[(x,y),(x-sign*11,y-6),(x-sign*11,y+6)]
    draw.polygon(head,fill=COLOR)

im=Image.open(SRC/'01_evaluation_workflow_v2.png').convert('RGB')
assert im.size==(1536,1024)
remove_vertical(im,1348,1359,220,652,1340)
draw=ImageDraw.Draw(im)
draw.rectangle((1396,679,1450,714),fill='white')
# Reference answers bypass the model, entering scoring, via an outer non-crossing route.
arrow(draw,[(1354,220),(1354,241),(1523,241),(1523,806),(509,806),(509,737)])
im.save(OUT/'01_evaluation_workflow.png',optimize=True)

im=Image.open(SRC/'04_local_validation_flow_v2.png').convert('RGB')
assert im.size==(1536,1024)
remove_vertical(im,1348,1362,355,653,1340)
draw=ImageDraw.Draw(im)
draw.rectangle((1279,639,1363,663),fill='white')
# Remove an unnecessary association-to-preview return connector before rerouting selection.
draw.rectangle((379,775,673,813),fill='white')
# Manual location takes precedence and enters the accepted standard-location path.
arrow(draw,[(1357,320),(1403,320),(1403,921),(489,921),(489,689)])
# The original text, not the model's location field, is used for matching.
arrow(draw,[(107,142),(69,142),(69,388),(706,388),(706,356)])
im.save(OUT/'04_local_validation_flow.png',optimize=True)

record={'origin':'gpt-image-2.5 through configured imagegen CLI, then precise local connector correction',
    'reason':'Generated references and manual-selection arrows were wrong; corrected to source-code semantics.',
    'semantics':['Reference fields feed scoring directly; they do not enter the AUV request.',
        'Response/failure records are a single collection stage.',
        'Original text directly feeds location matching.',
        'Manual location selection takes priority and enters standard location.',
        'Draft preview is not publication or database acceptance.'],
    'files':[{ 'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.glob('*.png'))],
    'visual_review':'pending'}
(OUT/'diagram_audit.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print('Corrected scientific workflow connectors against the actual evaluation and local application semantics.')
