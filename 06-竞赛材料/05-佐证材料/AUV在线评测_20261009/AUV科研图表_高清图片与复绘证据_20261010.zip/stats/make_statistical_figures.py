"""Render measured AUV results; all counts are rebuilt from saved real outputs.

No network calls, no generated artwork. Local plot dependency target: ./vendor.
Reproduction: bundled Python make_statistical_figures.py
"""
from pathlib import Path
import sys, json, math, statistics, hashlib, csv, importlib.util, re, decimal

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'vendor'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(r'D:\project\college\output\auv_live_evaluation_20261009')
EVIDENCE = ROOT / 'evidence'
FINDINGS = json.loads((EVIDENCE / 'findings.json').read_text(encoding='utf-8'))
SCORING = json.loads((EVIDENCE / 'full_scoring_v2.json').read_text(encoding='utf-8'))
RULE = json.loads((EVIDENCE / 'rule_baseline.json').read_text(encoding='utf-8'))
APP = json.loads((EVIDENCE / 'app_postprocess.json').read_text(encoding='utf-8'))
RUN = Path(FINDINGS['full_run'])
PUBRUN = Path(FINDINGS['public_run'])
PROTORUN = Path(FINDINGS['protocol_checks']['run'])
ROWS = [json.loads(s) for s in (RUN / 'requests.jsonl').read_text(encoding='utf-8').splitlines()]
CASES = {x['id']: x for x in json.loads((ROOT / 'cases.json').read_text(encoding='utf-8'))}

# Reuse the frozen, documented scorer without entering its main execution block.
spec = importlib.util.spec_from_file_location('frozen_scoring', ROOT / 'run_evaluation.py')
scorer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scorer)
for row in ROWS:
    if row.get('success'):
        row['checks'] = scorer.checks(CASES[row['id']], row['output'])
BYID = {x['id']: x for x in ROWS}
SEM = [x for x in ROWS if x['group'] == 'semantic']
assert len(SEM) == 72 and all(x.get('success') for x in SEM)

def pcheck(standard, actual, label):
    assert standard == actual, f'{label}: {actual!r} differs from frozen summary {standard!r}'
    return actual

FIELDS = ['type', 'building_id', 'building_name', 'floor', 'estimated_wait_min']
fields = {}
baseby = {x['id']: x for x in RULE['rows']}
for field in FIELDS:
    raw = sum(x['checks']['field_exact'][field] for x in SEM)
    normal = sum(x['checks']['normalized_field_exact'][field] for x in SEM)
    rule = sum(baseby[x['id']]['field_checks'][field] for x in SEM)
    frozen = FINDINGS['matched_rule_comparison'][field]
    pcheck(frozen['model_raw_pass'], raw, field + ' raw')
    pcheck(frozen['model_normalized_pass'], normal, field + ' normalized')
    pcheck(frozen['rule_pass'], rule, field + ' rule')
    fields[field] = {'model_raw': raw, 'model_normalized': normal, 'rule': rule, 'n': 72}

classes = ['safety', 'congestion', 'service', 'notice']
cm = np.zeros((4, 4), dtype=int)
for row in SEM:
    cm[classes.index(row['gold']['type']), classes.index(row['checks']['parsed']['type'])] += 1
for i, true in enumerate(classes):
    for j, predicted in enumerate(classes):
        pcheck(SCORING['semantic_confusion'][true][predicted], int(cm[i, j]), 'confusion')

missing = {}
for field, gold in [('floor', None), ('estimated_wait_min', None), ('time_window', 'unknown')]:
    rows = [x for x in SEM if x['gold'][field] == gold]
    missing[field] = {'correct': sum(x['checks']['field_exact'][field] for x in rows), 'n': len(rows)}
assert missing == {'floor': {'correct': 52, 'n': 52}, 'estimated_wait_min': {'correct': 51, 'n': 52}, 'time_window': {'correct': 33, 'n': 58}}

locations = {}
for group in ['catalog', 'alias', 'semantic']:
    rows = [r for r in APP['rows'] if r['group'] == group]
    def direct_location(row, key):
        obj = row.get(key) or {}
        return row.get('request_success', False) and all(obj.get(k) == row['gold'][k] for k in ['building_name', 'building_id'])
    locations[group] = {'raw': sum(direct_location(r, 'model_fields') for r in rows),
                        'validated': sum(direct_location(r, 'accepted') for r in rows), 'n': len(rows)}
    pcheck(APP['groups'][group]['model_location_correct'], locations[group]['raw'], group + ' location raw')
    pcheck(APP['groups'][group]['app_location_correct'], locations[group]['validated'], group + ' location validated')

pairs = {}
for group in ['placement', 'grounding', 'robustness']:
    paired_rows = [x for x in ROWS if x['group'] == group and x.get('success') and BYID[x['pair_id']].get('success')]
    before = sum(BYID[x['pair_id']]['checks']['normalized_gold_all_exact'] for x in paired_rows)
    after = sum(x['checks']['normalized_gold_all_exact'] for x in paired_rows)
    bid_before = sum(BYID[x['pair_id']]['checks']['field_exact']['building_id'] for x in paired_rows)
    bid_after = sum(x['checks']['field_exact']['building_id'] for x in paired_rows)
    pairs[group] = {'before_all': before, 'after_all': after, 'before_id': bid_before, 'after_id': bid_after, 'n': len(paired_rows)}
    frozen = SCORING['paired_comparisons'][group]
    for actual, key in [(before,'primary_pass'), (after,'variant_pass'), (bid_before,'primary_id_pass'), (bid_after,'variant_id_pass'), (len(paired_rows),'complete_pairs')]:
        pcheck(frozen[key], actual, group + ' ' + key)

proto = json.loads((PROTORUN / 'summary.json').read_text(encoding='utf-8'))
general_pairs = []
for row in proto['general_variant']:
    if row.get('success') and BYID[row['pair_id']].get('success'):
        row['checks'] = scorer.checks(CASES[row['pair_id']], row['output'])
        general_pairs.append((BYID[row['pair_id']], row))
general = {'n': len(general_pairs)}
for key, metric in [('strict', 'answer_correct'), ('normalized', 'normalized_answer_correct')]:
    general['before_' + key] = sum(a['checks'][metric] for a, b in general_pairs)
    general['after_' + key] = sum(b['checks'][metric] for a, b in general_pairs)
assert general == {'n': 16, 'before_strict': 10, 'after_strict': 14, 'before_normalized': 12, 'after_normalized': 15}

pubrows = [json.loads(s) for s in (PUBRUN / 'requests.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(pubrows) == 32
pubsummary = json.loads((PUBRUN / 'summary.json').read_text(encoding='utf-8'))
pub = {'correct': pubsummary['strict_correct'], 'n': pubsummary['attempted']}
assert pub == {'correct': 31, 'n': 32}
def canonical_number(s):
    return decimal.Decimal(s.replace(',', '').replace('$','').strip()).normalize()
pub_correct = 0
for r in pubrows:
    matches = re.findall(r'####\s*([-+]?\$?\d[\d,]*(?:\.\d+)?)', r.get('output', ''))
    correct = bool(matches and canonical_number(matches[-1]) == canonical_number(r['gold_final']))
    assert correct == r.get('strict_answer_correct', False)
    pub_correct += correct
pcheck(pub['correct'], pub_correct, 'GSM8K strict output rescore')

def nearest_rank(xs, pct):
    xs = sorted(xs)
    return xs[max(0, math.ceil(len(xs) * pct) - 1)]

latency = {}
for name, group, key in [('serial_complete', 'latency', 'elapsed_s'), ('stream_first', 'streaming', 'first_content_s'), ('stream_complete', 'streaming', 'elapsed_s')]:
    rows = [x for x in ROWS if x['group'] == group and x.get('success')]
    xs = [x[key] for x in rows]
    latency[name] = {'values': xs, 'n': len(xs), 'p50': nearest_rank(xs, .50), 'p95': nearest_rank(xs, .95)}
    section = SCORING['performance']['latency' if group == 'latency' else 'streaming']
    frozen = section['complete_response_s' if key == 'elapsed_s' else 'first_nonempty_content_chunk_s']
    for metric in ['n', 'p50', 'p95']:
        pcheck(frozen[metric], latency[name][metric], name + metric)

load = []
for concurrency in [1, 2, 4]:
    waves = [x for x in SCORING['performance']['load_waves'] if x['concurrency'] == concurrency]
    reqs = [x for x in ROWS if x['group'] == 'load' and x['concurrency'] == concurrency]
    assert len(waves) == 3 and len(reqs) == concurrency * 3 and all(r.get('success') for r in reqs)
    for wave in waves:
        wr = [r for r in reqs if r['wave'] == wave['wave']]
        assert wave['success'] == len(wr)
        assert wave['wave_wall_s'] >= max(r['elapsed_s'] for r in wr)
        assert abs(wave['requests_per_s'] - concurrency / wave['wave_wall_s']) < 1e-12
    load.append({'concurrency': concurrency, 'success': len(reqs), 'attempted': len(reqs),
                 'wall_s': [x['wave_wall_s'] for x in waves],
                 'throughput': [x['requests_per_s'] for x in waves],
                 'wall_mean_s': statistics.mean(x['wave_wall_s'] for x in waves),
                 'throughput_mean': statistics.mean(x['requests_per_s'] for x in waves)})

repeats = [x for x in ROWS if x['group'] == 'repeat']
repeat_groups = {}
for r in repeats:
    repeat_groups.setdefault(r['pair_id'], []).append(r)
assert len(repeat_groups) == 8 and all(len(rs) == 3 for rs in repeat_groups.values())
assert all(len({r['output'] for r in rs}) == 1 for rs in repeat_groups.values())
longs = [x for x in ROWS if x['group'] == 'long_context']
assert len(longs) == 8 and all(r['checks']['normalized_gold_all_exact'] for r in longs)
long_lengths = sorted({len(CASES[r['id']]['text']) for r in longs})
assert long_lengths == [914, 3559, 7101, 14185]

source_paths = [EVIDENCE / 'findings.json', EVIDENCE / 'full_scoring_v2.json', EVIDENCE / 'app_postprocess.json',
                EVIDENCE / 'rule_baseline.json', RUN / 'requests.jsonl', PUBRUN / 'requests.jsonl', PUBRUN / 'summary.json',
                ROOT / 'cases.json', ROOT / 'run_evaluation.py', PROTORUN / 'summary.json']
metric_data = {'fields': fields, 'confusion_matrix': cm.tolist(), 'class_order': classes, 'missing_semantic': missing,
               'locations': locations, 'pairs': pairs, 'general': general, 'gsm8k_subset': pub,
               'latency': latency, 'load': load, 'repeat_identical_groups': {'correct': 8, 'n': 8, 'calls_each': 3},
               'long_context': {'normalized_fields_correct': 8, 'n': 8, 'actual_character_lengths': long_lengths},
               'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths},
               'limits': ['自建合成输入含模板与成对/重复样本，不是人群随机抽样；不绘制推断性置信区间。',
                          '楼层统一格式评分仅将3F/三楼/3层等转换为数值；原始评分另保留。',
                          'GSM8K为固定32题子集，不是全量或官方排名；数据污染未审计。',
                          '客户端计时包含网络与队列；服务端其他用户负载未知。p95采用nearest-rank，小n下接近最大值。',
                          '本地地点核对不是云端/登录/数据库/移动端端到端验收。']}
(HERE / 'plot_metrics.json').write_text(json.dumps(metric_data, ensure_ascii=False, indent=2), encoding='utf-8')
with (HERE / 'semantic_record_audit.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['id', 'gold_type', 'predicted_type'] + [k + suffix for k in FIELDS for suffix in ['_model_raw', '_model_normalized', '_rule']])
    for r in SEM:
        writer.writerow([r['id'], r['gold']['type'], r['checks']['parsed']['type']] + [v for k in FIELDS for v in [r['checks']['field_exact'][k], r['checks']['normalized_field_exact'][k], baseby[r['id']]['field_checks'][k]]])
with (HERE / 'performance_record_audit.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['id', 'group', 'concurrency', 'wave', 'success', 'elapsed_s', 'first_content_s'])
    for r in ROWS:
        if r['group'] in ['latency', 'streaming', 'load']:
            writer.writerow([r['id'], r['group'], r.get('concurrency'), r.get('wave'), r.get('success'), r['elapsed_s'], r.get('first_content_s')])

font_path = Path(r'C:\Windows\Fonts\msyh.ttc')
assert font_path.exists(), 'Microsoft YaHei unavailable'
font_manager.fontManager.addfont(str(font_path))
font_family = font_manager.FontProperties(fname=str(font_path)).get_name()
plt.rcParams.update({'font.family': font_family, 'font.size': 11.5, 'axes.unicode_minus': False,
                     'svg.fonttype': 'path', 'pdf.fonttype': 42, 'axes.spines.top': False,
                     'axes.spines.right': False, 'axes.edgecolor': '#B5C2CD', 'axes.labelcolor': '#253D52',
                     'xtick.color': '#40596C', 'ytick.color': '#40596C', 'text.color': '#18344A',
                     'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white',
                     'axes.titleweight': 'bold', 'axes.titlesize': 12.5, 'legend.frameon': False})
BLUE = '#24557A'
TEAL = '#008777'
ORANGE = '#D98D2C'
PALE = '#EAF0F4'
GRAY = '#8DA3B2'

def clean(ax, orient='x'):
    ax.set_axisbelow(True)
    ax.grid(axis=orient, color='#DEE6EC', linewidth=.7)
    ax.tick_params(length=0, pad=4)
    ax.spines['left'].set_visible(False)
    ax.spines['bottom'].set_color('#B5C2CD')

def percent_axis(ax, horizontal=True):
    if horizontal:
        ax.set_xlim(0, 110)
        ax.set_xticks([0,25,50,75,100], ['0','25','50','75','100'])
        ax.set_xlabel('')
        clean(ax, 'x')
    else:
        ax.set_ylim(0, 110)
        ax.set_yticks([0,25,50,75,100])
        ax.set_ylabel('匹配率（%）', fontsize=10.5)
        clean(ax, 'y')

def title(ax, text):
    ax.set_title(text, loc='left', pad=12)

def header(fig, line):
    fig.text(.045, .966, line, fontsize=15, fontweight='bold', va='top')

def footer(fig, lines):
    for i, line in enumerate(lines):
        fig.text(.045, .073 - i * .033, line, fontsize=9.4, color='#496172', va='top')

def save(fig, name):
    for suffix in ['png', 'svg', 'pdf']:
        fig.savefig(HERE / (name + '.' + suffix), dpi=300)
    plt.close(fig)

def bar_counts(ax, labels, before, after, ns, before_label, after_label, fontsize=10):
    y = np.arange(len(labels))
    bh = .25
    ax.barh(y - .16, [100*k/n for k,n in zip(before,ns)], height=bh, color=BLUE, label=before_label)
    ax.barh(y + .16, [100*k/n for k,n in zip(after,ns)], height=bh, color=TEAL, label=after_label)
    for ys, counts, color in [(y-.16, before, BLUE), (y+.16, after, TEAL)]:
        for yy, k, n in zip(ys, counts, ns):
            value = 100*k/n
            if value > 50:
                ax.text(value - 2, yy, f'{k}/{n}', color='white', ha='right', va='center', fontsize=fontsize, fontweight='bold')
            else:
                ax.text(value + 2, yy, f'{k}/{n}', color=color, ha='left', va='center', fontsize=fontsize, fontweight='bold')
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    percent_axis(ax)
    ax.legend(loc='upper left', bbox_to_anchor=(0,-.24), ncol=2, fontsize=9.8, handlelength=1.2, columnspacing=1.0)

# Figure 1: raw comparable fields + explicitly separate floor normalization.
fig = plt.figure(figsize=(8.5,5.6))
gs = fig.add_gridspec(1,2, left=.17,right=.98,bottom=.25,top=.83,width_ratios=[1.45,1],wspace=.40)
ax = fig.add_subplot(gs[0,0])
labels = ['事件类型','地点编号','标准名称','楼层（原始）','等候分钟']
raw = [fields[k]['model_raw'] for k in FIELDS]
rules = [fields[k]['rule'] for k in FIELDS]
bar_counts(ax, labels, raw, rules, [72]*5, '模型原始字段','固定规则', fontsize=10.2)
ax.legend(loc='upper left', bbox_to_anchor=(0,-.14), ncol=2, fontsize=9.8, handlelength=1.2, columnspacing=1.0)
title(ax, 'A  同题字段对照  |  n = 72')
ax.scatter([100],[3-.16], marker='D', s=52, color=ORANGE, edgecolors='white', zorder=5)
ax.annotate('楼层统一格式后 72/72', xy=(100,3-.16), xytext=(22,2.53), color='#956014', fontsize=9.8,
            arrowprops={'arrowstyle':'-','color':ORANGE,'lw':1.1}, bbox={'facecolor':'white','edgecolor':'none','pad':2})
ax = fig.add_subplot(gs[0,1])
cmap = LinearSegmentedColormap.from_list('measured_blue',['#F3F6F8',BLUE])
ax.imshow(cm, cmap=cmap, vmin=0,vmax=18)
ax.set_xticks(range(4), ['安全','拥堵','服务','通知'], fontsize=10)
ax.set_yticks(range(4), ['安全','拥堵','服务','通知'], fontsize=10)
ax.set_xlabel('预测类型', fontsize=10.5)
ax.set_ylabel('参考类型', fontsize=10.5)
for i in range(4):
    for j in range(4):
        ax.text(j,i,str(cm[i,j]),ha='center',va='center',color='white' if cm[i,j]>9 else BLUE,fontsize=14,fontweight='bold')
ax.tick_params(length=0)
for spine in ax.spines.values():spine.set_visible(False)
title(ax, 'B  四类混淆矩阵')
ax.text(.5,-.36,'类型正确 71/72（98.6%）\n宏平均 F1 = 0.986',transform=ax.transAxes,ha='center',fontsize=11.3,color=BLUE)
header(fig,'事件提取：类型可靠，地点编号仍需核对')
footer(fig,['比例轴单位：%；分数标签为通过数/分母。时间字段原始匹配46/72。',
            '来源：72题实测与固定规则。楼层原始评分、统一格式评分分开报告。'])
save(fig,'01_semantic_fields_confusion')

# Figure 2: distinctions between application validation, null preservation, prompt grounding.
fig = plt.figure(figsize=(8.5,5.6))
gs = fig.add_gridspec(2,2, left=.17,right=.98,bottom=.22,top=.83,height_ratios=[1.2,1],wspace=.43,hspace=.93)
ax = fig.add_subplot(gs[0,0])
bar_counts(ax,['目录题','别名题','语义题'],[locations[k]['raw'] for k in ['catalog','alias','semantic']],
           [locations[k]['validated'] for k in ['catalog','alias','semantic']], [68,35,72], '原始输出','本地核对', fontsize=10)
title(ax,'A  标准名称与编号同时匹配')
ax = fig.add_subplot(gs[0,1])
ys = np.arange(3)
vals = [missing[k]['correct']/missing[k]['n']*100 for k in ['floor','estimated_wait_min','time_window']]
ax.barh(ys,vals,color=[TEAL,TEAL,ORANGE],height=.47)
for y,k in zip(ys,['floor','estimated_wait_min','time_window']):
    a=missing[k];value=100*a['correct']/a['n']
    ax.text(value-2,y,f"{a['correct']}/{a['n']}",ha='right',va='center',color='white',fontweight='bold',fontsize=11)
ax.set_yticks(ys,['楼层 → null','分钟 → null','时间 → unknown'],fontsize=10.5)
ax.invert_yaxis();percent_axis(ax)
title(ax,'B  未给定信息保持未知')
ax = fig.add_subplot(gs[1,:])
g = pairs['grounding']
bar_counts(ax,['地点编号','全部字段*'],[g['before_id'],g['before_all']],
           [g['after_id'],g['after_all']],[24,24],'无目录上下文','加入目录上下文',fontsize=11)
title(ax,'C  同题目录提示对照  |  24个完整配对')
ax.legend(loc='upper right',bbox_to_anchor=(1,-.24),ncol=2,fontsize=9.8,handlelength=1.2)
header(fig,'地点核对与未知信息：分别检查两类风险')
footer(fig,['比例轴单位：%；*仅统一楼层格式。B的分母为72题语义子集中对应缺失字段数。',
            '来源：真实输出与本地核对。仍有6例语义地点歧义；本地核对非端到端验收。'])
save(fig,'02_location_unknown_grounding')

# Figure 3: same-question controlled contrasts; public subset is never a global score.
fig = plt.figure(figsize=(8.5,5.6))
gs = fig.add_gridspec(2,2, left=.15,right=.97,bottom=.22,top=.83,height_ratios=[1,1.15],wspace=.43,hspace=.77)
ax = fig.add_subplot(gs[0,:])
bar_counts(ax,['指令放置\nn = 24','输入扰动\nn = 40'], [9,14],[9,15],[24,40], '原条件','变体条件',fontsize=11)
title(ax,'A  全部参考字段匹配（楼层统一格式）')
ax.legend(loc='upper right',bbox_to_anchor=(1,-.24),ncol=2,fontsize=9.8,handlelength=1.2)
ax = fig.add_subplot(gs[1,0])
bar_counts(ax,['严格值/类型','数值统一*'],[10,12],[14,15],[16,16],'原提示词','验证提示词',fontsize=10.6)
title(ax,'B  通用计算同题对照  |  n = 16')
ax = fig.add_subplot(gs[1,1])
ax.barh([0],[31/32*100],height=.48,color=TEAL)
ax.barh([0],[1/32*100],left=31/32*100,height=.48,color=ORANGE)
ax.text(48.5,0,'31/32 正确',ha='center',va='center',color='white',fontsize=14,fontweight='bold')
ax.annotate('1题错误',xy=(98.4375,0),xytext=(100,.70),ha='right',fontsize=10.8,color='#956014',arrowprops={'arrowstyle':'-','color':ORANGE})
ax.set_yticks([]);ax.set_ylim(-.6,.85);percent_axis(ax)
title(ax,'C  GSM8K固定32题样本')
header(fig,'提示词与公开样本：报告配对结果及适用范围')
footer(fig,['比例轴单位：%；*仅统一数字与数值字符串。A、B均为同题完整配对。',
            '来源：真实输出及固定公开样本；GSM8K非全量、非官方排名，各组不混算总分。'])
save(fig,'03_controlled_pairs_public_sample')

# Figure 4: individual latency values and all load waves preserved.
fig = plt.figure(figsize=(8.5,5.6))
gs = fig.add_gridspec(2,2, left=.19,right=.97,bottom=.19,top=.83,height_ratios=[1,1.2],wspace=.47,hspace=.78)
ax = fig.add_subplot(gs[0,:])
lat_names = ['serial_complete','stream_first','stream_complete']
labels = ['串行完整\nn = 12','流式首文本\nn = 6','流式完整\nn = 6']
for y,name,color in zip(range(3),lat_names,[BLUE,TEAL,ORANGE]):
    d=latency[name];xs=d['values']
    jitter=np.linspace(-.10,.10,len(xs))
    ax.scatter(xs,np.full(len(xs),y)+jitter,s=29,color=color,alpha=.70,zorder=3,edgecolors='white',linewidth=.35)
    ax.scatter([d['p50']],[y],s=65,marker='D',color=color,zorder=5,edgecolors='white',linewidth=.9)
    ax.plot([d['p50'],d['p95']],[y,y],color=color,lw=1.1,zorder=2)
    ax.text(42,y-.22,f"p50 {d['p50']:.2f} / p95 {d['p95']:.2f}",ha='right',va='center',fontsize=10.2,color=color)
ax.set_yticks(range(3),labels,fontsize=10.8);ax.set_ylim(2.35,-.4);ax.set_xlim(0,43)
ax.set_xticks([0,10,20,30,40]);ax.set_xlabel('客户端耗时（秒）',fontsize=10.5);clean(ax)
title(ax,'A  独立性能组：每次观测均保留（菱形为p50）')
ax = fig.add_subplot(gs[1,0])
cs=np.arange(3)
ax.bar(cs,[x['wall_mean_s'] for x in load],width=.55,color=BLUE,alpha=.92)
for i,r in enumerate(load):
    ax.scatter(i+np.array([-.11,0,.11]),r['wall_s'],color=ORANGE,s=26,edgecolors='white',linewidth=.6,zorder=3)
    ax.text(i,r['wall_mean_s']+1.15,f"{r['wall_mean_s']:.2f}",ha='center',fontsize=11.1,fontweight='bold',color=BLUE)
ax.set_xticks(cs,['1路\n3/3成功','2路\n6/6成功','4路\n12/12成功'],fontsize=10.5)
ax.set_ylim(0,31);ax.set_ylabel('整批墙钟耗时（秒）',fontsize=10.5);clean(ax,'y')
title(ax,'B  每种并发3批：平均批耗时')
ax = fig.add_subplot(gs[1,1])
ax.bar(cs,[x['throughput_mean'] for x in load],width=.55,color=TEAL,alpha=.92)
for i,r in enumerate(load):
    ax.scatter(i+np.array([-.11,0,.11]),r['throughput'],color=ORANGE,s=26,edgecolors='white',linewidth=.6,zorder=3)
    ax.text(i,max(r['throughput'])+.009,f"{r['throughput_mean']:.3f}",ha='center',fontsize=11.1,fontweight='bold',color=TEAL)
ax.set_xticks(cs,['1路','2路','4路'],fontsize=11);ax.set_ylim(0,.21)
ax.set_yticks([0,.05,.10,.15,.20],['0','.05','.10','.15','.20'])
ax.set_ylabel('请求吞吐（次/秒）',fontsize=10.5);clean(ax,'y')
title(ax,'C  逐批吞吐的算术平均')
header(fig,'响应性能：流式首文本与完整耗时分开衡量')
footer(fig,['p95用nearest-rank，小n时为最大值；流式29.68秒首文本异常值保留。',
            '来源：独立性能组。计时含网络与队列；橙点为逐批值，非GPU解码速度。'])
save(fig,'04_latency_and_concurrency')

(HERE / 'figure_audit.json').write_text(json.dumps({'data_recalculation':'passed', 'source_files_count':len(source_paths),
    'semantic_n':72, 'main_requests_n':len(ROWS), 'four_figures_rendered':True, 'visual_review':'pending',
    'font':str(font_path), 'statistical_method':'counts / stated denominators; nearest-rank quantiles; arithmetic mean of wave throughput',
    'artwork_origin':'matplotlib rendering of preserved real outputs, not AI generated'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'output_directory':str(HERE), 'data_audit':'passed', 'figures':4, 'formats':['PNG300dpi','SVG','PDF']},ensure_ascii=False))
