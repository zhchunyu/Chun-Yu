# AUV实测科研图（2026-10-10）

本目录的4组统计图由保存的真实模型回复和计时记录绘制，未经生图模型重绘。它们与AI辅助绘制的框图应分别标注来源。

## 文件

每组提供300 dpi PNG（2550 × 1680像素）、保留文字轮廓的SVG、嵌入字体的PDF。`plot_metrics.json`记录所有图中数值、分母、逐次性能观测和10个源文件SHA256；两个CSV保留逐记录审计。`make_statistical_figures.py`重新读取原始证据，不发网络请求，并逐项断言统计值与冻结汇总一致。

## 建议图注

1. **事件字段与混淆矩阵。** 同一组72条语义输入，每类18题。模型与固定词典/正则基线按原始字段值比较；楼层统一格式后72/72另以菱形标出，不替代原始52/72。混淆矩阵行是参考类型、列是预测类型。固定基线未经模型输出调参；结果不能用于推断人群输入分布。
2. **地点核对、缺失信息和目录提示。** A比较真实输出经现有本地`validateExtractedEvent`处理前后，要求标准名称与编号同时正确；目录68题包含一次请求失败。别名原始0/35是标准化不匹配，不能解读为35题均未识别地点。B限定72题语义子集，其中缺失楼层52题、缺失分钟52题、缺失时间58题。C为同24题加目录上下文的完整配对，仅将楼层统一格式后判断全部参考字段。本地核对不是云端/登录/数据库/移动端端到端验收，语义题仍有6例地点歧义。
3. **提示词与公开固定样本。** A分别显示指令由user移至system的24对和输入扰动40对，全字段只统一楼层格式。B为同16题原提示词与增加内部计算核验的提示词对照，严格值/类型与数值字符串统一评分分开；类型差异不等于数学计算错误。C为GSM8K测试集固定32题、seed 20261009，zero-shot协议，按`####`数值提取评分。31/32仅适用于该子集，不是全量GSM8K或官方排名，数据污染未审计。所有组分母独立，不计算混合总分。
4. **延迟与并发。** A为独立串行12次和流式6次的逐次客户端计时；每个点均保留，菱形为nearest-rank p50，线段延伸至p95。在n=6或12时该定义下p95等于最大观测值，包含流式首文本29.6848954秒异常。B、C分别给出并发1/2/4路各3批整批墙钟均值及逐批请求吞吐的算术均值，橙点是逐批值。网络、队列和输出均包含在客户端耗时，其他服务用户负载未知；这些指标不是纯GPU解码速度。

可在正文保留两条补充观察：8组重复任务各调用3次，原始输出一致；8个重复填充长文本任务在楼层统一格式后全部参考字段一致，实际字符长度为914、3559、7101、14185（各首/尾2种放置）。这些观察不证明广泛正确性或复杂文档理解。

## 复绘

图表ZIP包含图像、脚本、数据审计和`requirements.txt`，不包含较大的`vendor`依赖，也不包含全部原始模型回复。复绘必须同时保留原始证据，所需证据已包含在旧交付的`AUV在线评测_原始证据与复跑工具.zip`中。该ZIP从根目录展开即有`cases.json`、`run_evaluation.py`、`evidence`、`runs`、`public_benchmark`和`protocol_runs`；不需要API密钥，也不再调用AUV服务。

### 在本机现有工作目录复绘

当前原始证据仍在`D:\project\college\output\auv_live_evaluation_20261009`，无需重新解压。在PowerShell执行下面的实际命令。`vendor`仅写入本任务统计图目录，不改变全局Python环境；已有依赖时跳过安装一行。安装依赖可能访问软件仓库，之后的统计与绘图均为本地执行。

```powershell
$taskPython = 'C:\Users\y7000\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
Set-Location -LiteralPath 'D:\project\college\output\auv_scientific_20261010\stats'
& $taskPython -m pip install --target '.\vendor' -r '.\requirements.txt'
& $taskPython '.\make_statistical_figures.py'
```

### 将两个ZIP移到其他目录或电脑后复绘

1. 将原始证据ZIP解压到一个新目录，例如`D:\AUV复绘\raw`，确认该目录直接包含`cases.json`。将图表ZIP解压到另一个新目录，进入其中含`make_statistical_figures.py`的`stats`目录。
2. 在解压后的绘图脚本副本中，将下面4行改为新证据根目录及固定run相对位置。**仅调整绘图脚本副本**，原始证据和`findings.json`保持不变。只改`ROOT`不够，因为原始`findings.json`还保存了当时的3个绝对run路径；下面的明确路径会覆盖这些读取路径。

```python
ROOT = Path(r'D:\AUV复绘\raw')
RUN = ROOT / 'runs' / '20261009_191150_420593'
PUBRUN = ROOT / 'public_benchmark' / 'runs' / '20261009_192133_762718'
PROTORUN = ROOT / 'protocol_runs' / '20261009_193551_399270'
```

3. 在该`stats`目录打开PowerShell，用Python 3.12执行以下命令；若本机仍有Bundled Python，可直接使用上面的完整执行路径，否则将`python`替换为本机Python 3.12的路径。

```powershell
python -m pip install --target '.\vendor' -r '.\requirements.txt'
python '.\make_statistical_figures.py'
```

字体要求Windows微软雅黑`C:\Windows\Fonts\msyh.ttc`。脚本会重算逐项计数并与冻结汇总断言一致；不一致会停止执行。运行会重新写入所在`stats`目录的4组PNG/SVG/PDF和数据审计，不改原始模型证据，因此建议在解压副本中复绘。复绘后需重新视觉审阅，`figure_audit.json`的`visual_review`会重置为`pending`。`vendor`无需打包进交付证据，也不应加入版本控制。
